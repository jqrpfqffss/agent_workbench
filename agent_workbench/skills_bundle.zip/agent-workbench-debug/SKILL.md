---
name: agent-workbench-debug
description: Use for UART CLI debug, ready or prompt failures, flash failures, regression investigation, and evidence-first STM32 root-cause analysis in repositories that use agent_workbench. Combine this with agent-workbench-toolbox for command details and artifact routing.
---

# Agent Workbench Debug

Use this for automated debug workflows. Pair it with `agent-workbench-toolbox`.

This skill is for choosing the debug route, ranking evidence, and selecting the smallest next action after failure.

## Default Debug Split

- Use the fast path when you mainly need current status.
- Use the explicit debug path when you need UART, diag, monitor, or regression evidence separately.

## Read Next

- Debug flow: [references/debug-flow.md](references/debug-flow.md)
- CLI diagnostic classifications: [references/diag-codes.md](references/diag-codes.md)
- Evidence-first root cause ranking: [references/evidence-first-root-cause.md](references/evidence-first-root-cause.md)
- Command selection for UART, diag, and monitor: [references/debug-command-playbook.md](references/debug-command-playbook.md)
- Detailed debug funnel and hypothesis management: [references/debug-methodology.md](references/debug-methodology.md)
- Debug experiment design: [references/debug-experiment-playbook.md](references/debug-experiment-playbook.md)
- Real hardware verification: [../agent-workbench-toolbox/references/hardware-verification.md](../agent-workbench-toolbox/references/hardware-verification.md)
- Debug report template: [references/debug-report-template.md](references/debug-report-template.md)

## Rules

- Read verdict and diagnostic artifacts before patching code.
- Prefer the smallest next step over a broad speculative rewrite.
- Treat `blocked` as an environment or hardware warning unless stronger evidence disproves it.
- Report hardware blockers directly instead of pretending they are source bugs.
- Always decompose the failure into layers before deciding which `agent_workbench` tool to call next.
- Do not ask for approval before flash, reset, UART, diag, monitor, verify, report, or compare.
- Use the debug report template when summarizing root cause, blockers, or next experiments for the user.
