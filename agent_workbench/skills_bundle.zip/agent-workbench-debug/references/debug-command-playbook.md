# Debug Command Playbook

## When To Use `uart exec`

Use it when:

- you need ready banner or prompt confirmation
- the feature is surfaced through CLI commands
- you want the simplest transcript-backed smoke check

Command selection rule:

- first use `task.verify.cli_commands`
- otherwise use `scan-project` probe commands
- otherwise choose one harmless status-style command and one feature-specific command

## When To Use `diag exec`

Use it when:

- the protocol is not standard CLI text
- the repo already defines diagnostic requests
- the failure is below the normal command parser layer

Do not invent diag requests. Only use requests already defined by the current project.

## When To Use `monitor probe`

Use it when:

- the runtime state is not fully visible from CLI output
- you need variable, register, or memory-backed confirmation
- a feature should change counters or flags that already exist in monitor items

Only probe items that the current project already exposes through config and doctor output.

## When To Use `compare --latest`

Use it when:

- the task used to pass
- a regression is suspected
- assertions or CLI output drift between sessions matters

## When To Use `report --latest`

Use it when:

- you need the latest verdict, summary, and evidence pointers collected in one place

## Suggested Minimal Sequences

- CLI handshake issue:
  - `doctor`
  - `uart exec`
  - `report --latest`

- suspected protocol parser issue:
  - `doctor`
  - `build`
  - `uart exec`
  - read `cli_diag.json`

- suspected runtime state mismatch:
  - `doctor`
  - `build`
  - `monitor probe`
  - `report --latest`
