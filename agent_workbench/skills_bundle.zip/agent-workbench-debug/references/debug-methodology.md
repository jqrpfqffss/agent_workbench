# Debug Methodology

Use this document when you need more than a simple command sequence. It defines how to debug efficiently with `agent_workbench`.

## Core Principle

Debug from the outside in. Do not start by editing source code.

Always classify the failure into one of these layers first:

1. environment and tooling
2. build and link
3. flash and boot
4. UART handshake
5. CLI parser and dispatch
6. feature behavior
7. observability and host capture
8. regression drift

## Debug Output Contract

When OpenCode reports a debug finding, it should include:

- symptom
- layer
- strongest evidence
- top 2-3 hypotheses
- next confirming command or artifact
- whether source edits are justified yet

## Efficient Debug Funnel

### 1. Confirm Environment And Tooling

Run:

- `doctor`

Goal:

- confirm config paths, flash tooling, UART settings, monitor readiness, and task assets

If this layer fails:

- stop here
- report the environment blocker

### 2. Confirm Build Health

Run:

- `build`
- `fix-build` only if the build failed

Goal:

- avoid spending time on runtime theories when the binary is not trustworthy

### 3. Confirm Flash And Boot

Use when the failure may be on hardware.

Run:

- `flash` when firmware must be reloaded
- `report --latest` if the latest verdict already captured a flash issue

Goal:

- distinguish "firmware never ran" from "firmware ran but behaved incorrectly"

### 4. Confirm UART Handshake

Run:

- `uart exec` with task-derived or scan-derived probe commands

Goal:

- determine whether ready banner, prompt, and basic command exchange are healthy

Interpretation:

- no bytes: environment or connectivity first
- ready missing: boot or startup contract first
- prompt missing: CLI lifecycle first

### 5. Localize Parser Or Dispatch Problems

Use when bytes arrived but commands did not behave correctly.

Read:

- `cli_diag.json`
- `cli_transcript.log`
- current CLI source ownership from `scan-project`

Hypotheses:

- command not registered
- parser strips or splits input incorrectly
- handler never reached
- handler ran but stable response contract drifted

Choose the smallest confirming action before editing code.

### 6. Validate Feature Behavior

If the CLI path is healthy but the behavior is wrong:

- compare expected task acceptance against actual output
- if needed, use `monitor probe` to verify runtime state that the CLI does not expose cleanly

Examples:

- control command succeeds but status command is wrong
- command output is right but monitor values never change
- monitor values change but assertion strings drifted

### 7. Separate Observability Failure From Real Feature Failure

Use when:

- `tx_or_host_rx`
- `diag_unavailable`
- monitor data is absent

Goal:

- avoid claiming a firmware bug when the evidence path is the real problem

### 8. Check For Regression Drift

Use when the behavior used to work.

Run or read:

- `compare --latest`
- `compare_delta.json`
- `compare_brief.md`

Goal:

- identify what changed:
  - output text
  - prompt behavior
  - warning-like lines
  - assertion count
  - monitor last values

## Hypothesis Management

For each failure, keep the hypothesis set small:

1. write the strongest observed symptom
2. list 2-3 likely causes
3. choose one confirming command or artifact
4. only then patch code if the evidence points to source behavior

## Layer-To-Tool Map

- environment and tooling: `doctor`
- build and link: `build`, then `fix-build`
- flash and boot: `flash`, `reset`, `report --latest`
- UART handshake: `uart exec`, `cli_diag.json`, `cli_transcript.log`
- CLI parser and dispatch: `scan-project`, `cli_diag.json`, CLI source ownership
- feature behavior: `verify current`, task assertions, feature-specific CLI or diag command
- observability and host capture: `monitor probe`, `diag exec`, transcript review
- regression drift: `compare --latest`, `compare_delta.json`

Bad debug behavior:

- edit code before reading `session_verdict.json`
- rerun long command chains without learning from artifacts
- assume UART, flash, or monitor is healthy because source looks reasonable

Good debug behavior:

- use verdict and diagnostics to cut the search space
- confirm one layer at a time
- stop immediately on hardware or environment blockers
