# Debug Flow

## Fast Path

Use this when the user wants quick status:

1. `doctor`
2. `verify current --json`, adding `--task <task.yaml>` only when the project already uses a mature matching task
3. Read `direct_verify_summary.json`
4. Read latest `session_verdict.json`

## Explicit Debug Path

Use this when you need deeper evidence separation:

1. `doctor`
2. `build`
3. `uart exec`
4. `diag exec` if the task or protocol needs it
5. `monitor probe` if runtime state matters
6. `session debug`
7. `report --latest`
8. `compare --latest` when regression evidence matters

## Evidence Order

1. `session_verdict.json`
2. `session_brief.md`
3. `cli_diag.json`
4. `cli_transcript.log`
5. `compare_delta.json`
6. `monitor_samples.csv`
7. `doctor_report.json`

## Stop Conditions

Stop and report when:

- `doctor` fails
- flash or reset is blocked
- the COM path is unavailable
- diagnostics are unavailable and no stronger evidence exists
