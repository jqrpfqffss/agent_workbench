# PowerShell Safe Invocation

In Windows PowerShell, always call the batch entry point like this:

```powershell
cmd /c ".\agent_workbench.bat <subcommand> ... --json"
```

## Safe Examples

```powershell
cmd /c ".\agent_workbench.bat doctor --json"
cmd /c ".\agent_workbench.bat build --json"
cmd /c ".\agent_workbench.bat verify current --json"
```

## Do Not Do These

- bare `agent_workbench.bat ...` in PowerShell
- `cd ... && agent_workbench.bat ...`
- multiple shell actions chained into one long command
- omitting `--json` when the output is intended for machine consumption

## Path Handling

- Prefer repo-root relative paths when already in the project root.
- Quote paths with spaces.
- Use forward slashes inside yaml or task content only when it helps portability.

## Workflow Rule

- Run one meaningful `agent_workbench` command at a time.
- Read its JSON result.
- Then decide the next command.
