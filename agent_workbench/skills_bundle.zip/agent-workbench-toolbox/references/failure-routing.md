# Failure Routing

Use this file after a command or verification step fails.

## Build Fail

Symptoms:

- `build` returns `exit_code != 0`

Read:

1. build JSON `errors[0]`
2. `fix-build --json`
3. `build.log`

Next step:

- apply the smallest source fix suggested by `fix-build`
- rerun `build`

Stop and report when:

- build still fails after targeted fixes
- the failure is clearly environmental or toolchain-related

## Flash Fail

Symptoms:

- `flash` returns `exit_code != 0`
- `session_verdict.json` summary says flash failed

Read:

1. flash JSON payload
2. `commands.log`
3. `doctor_report.json`

Next step:

- report a hardware or tooling block
- do not keep editing firmware until flashing is healthy

## Ready Missing

Symptoms:

- `uart exec` did not see the configured ready banner
- `cli_diag.json` classification is `ready_missing`

Read:

1. `cli_diag.json`
2. `cli_transcript.log`
3. `doctor_report.json`

Next step:

- confirm the UART contract in config
- confirm the board actually booted into the expected firmware
- treat this as environment or firmware-startup blocking until evidence says otherwise

## Prompt Missing

Symptoms:

- prompt was not seen
- `cli_diag.json` classification is `prompt_missing`

Read:

1. `cli_diag.json`
2. `cli_transcript.log`
3. `session_brief.md`

Next step:

- verify whether bytes arrived but prompt logic stalled
- if command output is present without prompt, inspect CLI prompt handling before broad edits

## Parser Fail

Symptoms:

- `cli_diag.json` classification is `parser_no_command`

Read:

1. `cli_diag.json`
2. `cli_transcript.log`
3. relevant CLI source files

Next step:

- inspect parser, command dispatch, and command registration
- keep the fix focused on the CLI path

## Host Receive Or TX Fail

Symptoms:

- `cli_diag.json` classification is `tx_or_host_rx`

Read:

1. `cli_diag.json`
2. `cli_transcript.log`
3. latest `session_verdict.json`

Next step:

- check whether the target likely responded but the host did not capture it cleanly
- avoid over-claiming a firmware bug without stronger evidence

## Diag Unavailable

Symptoms:

- `cli_diag.json` classification is `diag_unavailable`

Read:

1. `cli_diag.json`
2. `doctor_report.json`

Next step:

- report that the diagnostic backend could not provide full classification
- use transcript and verdict evidence without pretending certainty

## Monitor No Data

Symptoms:

- `monitor probe` or `monitor run` fails
- monitor artifacts are missing or empty

Read:

1. monitor JSON payload
2. `doctor_report.json`
3. `commands.log`

Next step:

- treat this as an observability block first
- do not claim runtime behavior from missing samples

## Assertion Fail

Symptoms:

- verify summary reports failed assertions
- `session_verdict.json` status is `fail` because of assertions

Read:

1. `assertions.jsonl`
2. `session_verdict.json`
3. `compare_delta.json` if this is a regression
4. `cli_transcript.log` or `monitor_samples.csv` depending on assertion type

Next step:

- identify the first failing assertion
- determine whether the failure is due to task design, generated assets, source behavior, or environment

## Environment Block

Symptoms:

- `doctor` fail count is non-zero
- verify summary status is `blocked`

Read:

1. `doctor_report.json`
2. `direct_verify_summary.json`

Next step:

- report the blocking layer directly
- stop before source edits unless the blocker is unrelated to the task
