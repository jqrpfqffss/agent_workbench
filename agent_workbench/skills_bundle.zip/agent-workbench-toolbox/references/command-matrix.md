# Command Matrix

Every `agent_workbench` JSON command returns the common top-level fields:

- `command`
- `exit_code`
- `status`
- `summary`
- `details`
- `artifacts`
- `timestamp`

Use `cmd /c ".\agent_workbench.bat ... --json"` from the repo root.

## Core Startup

### `doctor`

```powershell
cmd /c ".\agent_workbench.bat doctor --json"
```

Use when:

- starting any workflow
- validating environment, paths, flash tooling, UART contract, integrations, and runtime capabilities

Read:

- `details.fail_count`
- `details.warn_count`
- `details.results[]`
- `artifacts.report_json`
- `artifacts.report_md`

Success:

- `exit_code == 0`
- `details.fail_count == 0`

If it fails:

- stop and report environment blockers before editing source

### `scan-project`

```powershell
cmd /c ".\agent_workbench.bat scan-project --json"
```

Use when:

- deciding what files, CLI commands, handles, monitor symbols, or project capabilities already exist
- choosing runtime probes and source reading targets

Read:

- `details.project`
- `details.detected_init_functions`
- `details.existing_handles`
- `details.user_code_regions`
- `details.cli_commands`
- `details.uart`
- `details.tasks`, only if the migrated project already uses task-driven flows
- `details.planner_templates`

Success:

- `exit_code == 0`

If it fails:

- treat project facts as unknown and stop before assuming structure

## Build And Repair

### `build`

```powershell
cmd /c ".\agent_workbench.bat build --json"
```

Use when:

- validating source changes
- checking current branch health before hardware work

Read:

- `exit_code`
- `summary`
- `details.error_count`
- `details.warning_count`
- `artifacts.log_path`
- `errors[]`
- `warnings[]`

Success:

- `exit_code == 0`

If it fails:

- inspect `errors[0]`
- use `fix-build` if the failure is a normal compiler or linker issue

### `fix-build`

```powershell
cmd /c ".\agent_workbench.bat fix-build --json"
```

Use when:

- `build` failed and you need structured repair hints from the latest log

Read:

- `details.fix_count`
- `fixes[]`
- each fix's `file`, `line`, `message`, `suggested_fix`

Success:

- at least one targeted fix suggestion is returned

If it fails:

- read the build log directly and report that no structured suggestion was produced

## Hardware Actions

### `flash`

```powershell
cmd /c ".\agent_workbench.bat flash --json"
```

Use when:

- build already passed
- hardware validation is needed for the current claim

Read:

- `exit_code`
- `details.method`
- `artifacts.log_path`

Success:

- `exit_code == 0`

If it fails:

- stop and report a hardware or tooling block

### `reset`

```powershell
cmd /c ".\agent_workbench.bat reset --json"
```

Use when:

- reset behavior needs to be validated independently of flash

Read:

- `exit_code`
- `details.method`
- `artifacts.log_path`

## UART, Diag, And Monitor

### `uart exec`

```powershell
cmd /c ".\agent_workbench.bat uart exec --reset-first --expect-ready --command <probe_command_1> --command <probe_command_2> --json"
```

Use when:

- validating CLI handshake, prompt, and command responses
- checking a feature through CLI-visible behavior

Choose commands from, in order:

1. `scan-project` output under `details.uart.probe_commands`
2. existing CLI help/status commands from the current project
3. regression evidence that already proves the behavior
4. explicit task commands only when the user requested task-driven validation

Read:

- `details.saw_ready`
- `details.saw_prompt`
- `details.timeout_commands`
- `artifacts.transcript_path`
- `artifacts.diag_path`
- `transcript[]`
- `diagnosis`

Success:

- `exit_code == 0`
- ready and prompt were seen when expected

If it fails:

- inspect `diagnosis`
- then read `cli_diag.json` and `cli_transcript.log`

### `diag exec`

```powershell
cmd /c ".\agent_workbench.bat diag exec --script <requests.txt> --json"
```

Use when:

- the project uses a non-CLI diagnostic UART exchange
- probing binary requests or low-level command paths

Read:

- `details.exchange_count`
- `details.error`
- `artifacts.log_path`
- `artifacts.result_path`

Success:

- `exit_code == 0`

### `monitor probe`

```powershell
cmd /c ".\agent_workbench.bat monitor probe --json"
```

Use when:

- validating symbol values, memory-mapped state, or runtime counters
- checking whether monitor items are readable before a longer run

Read:

- `details.items`
- `artifacts.out_dir`

Success:

- `exit_code == 0`

### `monitor run`

```powershell
cmd /c ".\agent_workbench.bat monitor run --json"
```

Use when:

- collecting a timed monitor sample set

Read:

- `artifacts.out_dir`

Then inspect the generated `monitor_samples.csv` and `monitor_samples.jsonl`.

## Testing And Verification

### `test generate`

```powershell
cmd /c ".\agent_workbench.bat test generate --task <task.yaml> --json"
```

Use when:

- the user explicitly asked for task-driven generation, or the project already has a mature matching task

Do not use this as the default test path in migrated projects.

Read:

- `artifacts.out_dir`

Then inspect the generated files under `generated/tasks/<task_id>/`.

### `test run`

```powershell
cmd /c ".\agent_workbench.bat test run --json"
```

Use when:

- running the configured unit or host-side test command

Read:

- `exit_code`
- `artifacts.log_path`

### `verify current`

```powershell
cmd /c ".\agent_workbench.bat verify current --json"
```

Use when:

- you want the shortest end-to-end validation summary for the current project
- add `--task <task.yaml>` only when the user explicitly requested task-driven validation or a mature matching task already exists

Read:

- `status`
- `summary`
- `details.steps`
- `artifacts.summary_path`
- runtime `direct_verify_summary.json`
- runtime `direct_verify_summary.md`

Success:

- `status == "pass"`

If it fails or blocks:

- read `direct_verify_summary.json`
- then the latest `session_verdict.json`

## Reporting And Comparison

### `report --latest`

```powershell
cmd /c ".\agent_workbench.bat report --latest --json"
```

Use when:

- rebuilding the latest evidence summary
- preparing a user-facing evidence chain

Read:

- `details.summary_line`
- `artifacts.report_path`
- `artifacts.session_dir`

### `compare --latest`

```powershell
cmd /c ".\agent_workbench.bat compare --latest --json"
```

Use when:

- checking regressions between the latest two sessions

Read:

- `artifacts.report_path`
- `artifacts.delta_path`

Then inspect `compare_delta.json` and `compare_brief.md`.

## Context And Session Helpers

### `context`

```powershell
cmd /c ".\agent_workbench.bat context --mode <debug|feature|test> --stage <analyze|implement|verify|resume> --json"
```

Use when:

- you need a constrained reading set
- you want a stage-specific brief for implement, verify, or resume

Read:

- `artifacts.out_path`

Then open the generated `*_brief.md`, `*_facts.json`, `*_constraints.json`, `*_resume.md`, or `*_paste.md`.

### `session debug`

```powershell
cmd /c ".\agent_workbench.bat session debug --json"
```

Use when:

- running a full debug evidence capture session

Read:

- `artifacts.session_dir`
- `artifacts.summary_path`

### `session feature`

```powershell
cmd /c ".\agent_workbench.bat session feature --json"
```

Use when:

- running the longer feature evidence capture session

Read:

- `artifacts.session_dir`
- `artifacts.summary_path`
