# Real Hardware Verification Gate

Use this file whenever flash, reset, UART, diag, or monitor evidence is needed.

## Hardware Execution Rule

Flash, reset, UART, diag, monitor, verify, report, and compare do not require user approval in these skills. Run the needed workbench command directly when it is part of the requested automation.

Before running hardware validation:

- confirm `build` passed when firmware changed
- confirm `doctor` has no blocking failures
- confirm the evidence will be cited in the final report

## Minimum Real-Board Verification

For most feature tasks, real-board verification should prove:

1. firmware built successfully
2. firmware was flashed or reset successfully when hardware validation was needed
3. ready banner and prompt were observed when the project defines them
4. task-specific commands or probes produced expected evidence
5. report or verdict artifacts were generated

## CLI-Based Feature Verification

Use when the feature has a text CLI surface.

Commands:

- use `scan-project` probe commands
- add one feature-specific command when the current CLI surface or user goal defines it

Evidence:

- `cli_transcript.log`
- `cli_diag.json`
- `session_verdict.json`
- `assertions.jsonl`, when produced

Pass criteria:

- expected ready and prompt are seen
- no timed-out probe command
- expected stable strings or fields appear

## Diag-UART Verification

Use when the target behavior is exposed through diagnostic frames, binary protocol, or low-level service requests.

Rules:

- do not invent request bytes
- use project-defined requests or current-source protocol evidence
- record request and response artifacts

Evidence:

- `diag_exec_result.json`
- `diag_exchange.log`

Pass criteria:

- expected exchanges complete
- response shape or fields match the current behavior contract

## Monitor Verification

Use when runtime state matters and CLI text is insufficient.

Rules:

- only probe configured monitor items
- treat missing samples as an observability block, not a feature failure

Evidence:

- `monitor_samples.csv`
- `monitor_samples.jsonl`
- monitor command JSON payload

Pass criteria:

- values are readable
- value range, last value, or trend matches the expected behavior

## Evidence Report

At the end of hardware verification, report:

- build result
- flash or reset result
- UART, diag, or monitor result
- relevant artifact paths
- whether hardware validation passed, failed, or was skipped
