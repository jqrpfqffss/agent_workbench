# Artifact Map

Use this file to decide which generated output to read first.

## Runtime Outputs

### `agent_workbench/runtime/doctor_report.json`

- Structured environment truth
- Read first when `doctor` fails or warns

### `agent_workbench/runtime/doctor_report.md`

- Human-readable doctor summary
- Use for quick reporting after reading the JSON

### `agent_workbench/runtime/direct_verify_summary.json`

- Compact end-to-end result for `verify current`
- Read first after any verify run

### `agent_workbench/runtime/direct_verify_summary.md`

- Human-readable verify summary
- Good for short status reporting

### `agent_workbench/runtime/build.log`

- Full build output
- Read when `build` fails and `fix-build` is insufficient

### `agent_workbench/runtime/unit.log`

- Full unit or host test output
- Read when `test run` fails

### `agent_workbench/runtime/cli_transcript.log`

- Latest CLI transcript
- Read after `uart exec` or when debugging command behavior

### `agent_workbench/runtime/diag_exec_result.json`

- Latest diag execution result
- Read after `diag exec`

### `agent_workbench/runtime/diag_exchange.log`

- Full UART diagnostic exchange log
- Use when the result JSON is not enough

### `agent_workbench/runtime/context_pack_*`

- Stage-specific low-context artifacts
- Use when a workflow skill tells you to read a specific stage pack

## Evidence Session Outputs

These live under `agent_workbench/evidence/sessions/<session_name>/`.

### `session_verdict.json`

- Best single file for latest pass, fail, or blocked status
- Read first after a failed feature or debug session

### `session_brief.md`

- Short evidence-first summary
- Good second read after `session_verdict.json`

### `session_summary.md`

- Expanded summary with evidence file presence and verdict snapshot
- Read when `session_brief.md` is not enough

### `feature_summary.md`

- Feature-session specific summary
- Use in implementation or regression follow-up

### `commands.log`

- Command execution log for the session
- Useful for hardware and tooling failures

### `cli_diag.json`

- Structured CLI diagnostic classification
- Read whenever `uart exec` or verify reports a CLI failure

### `cli_transcript.log`

- Session-local CLI transcript
- Prefer this over the runtime transcript when a session path is known

### `assertions.jsonl`

- Individual black-box assertion results
- Read when verify says assertions failed

### `compare_delta.json`

- Machine-readable regression delta between two sessions
- Read first for regression analysis

### `compare_brief.md`

- Short comparison summary
- Good for user-facing regression reporting

### `monitor_samples.csv`

- Primary monitor output for numeric state and trends
- Use with monitor-driven acceptance or debug

### `monitor_samples.jsonl`

- JSONL form of the same monitor sample stream
- Useful when CSV formatting is inconvenient

## Generated Task Outputs

These live under `agent_workbench/generated/tasks/<task_id>/`.

### `blackbox_assertions.yaml`

- Generated black-box verification contract
- Read first for test intent

### `unit_test_plan.md`

- Generated unit or host-test plan
- Read when the user asks about test coverage

### `implementation_brief.md`

- Compact task-specific implementation guidance
- Use before editing source in a task-driven workflow

### `task_snapshot.json`

- Normalized task spec snapshot
- Read when you need exact task fields

### `*_host_test_skeleton.c`

- Generated host-side test scaffold
- Use when the task calls for host-side extensions

## Read Order By Situation

### After `verify current`

1. `direct_verify_summary.json`
2. latest `session_verdict.json`
3. latest `session_brief.md`
4. latest `assertions.jsonl`
5. latest `cli_diag.json`

### After `build` failure

1. build JSON payload
2. `fix-build` output
3. `build.log`

### After CLI or UART failure

1. `cli_diag.json`
2. `cli_transcript.log`
3. `session_verdict.json`
4. `doctor_report.json`

### After regression or behavior drift

1. `compare_delta.json`
2. `compare_brief.md`
3. `session_verdict.json`
4. `assertions.jsonl`
