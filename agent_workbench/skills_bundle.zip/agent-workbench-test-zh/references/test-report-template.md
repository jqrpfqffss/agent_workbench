# 测试生成与验证报告模板

最终测试设计和验证回复按此结构生成。

## 测试结果

- 结论：通过 / 失败 / 部分通过 / 阻塞
- 目标行为：`<behavior>`
- 验证模式：runtime evidence / 可选 task-driven / 混合

## 覆盖摘要

- 正常路径：covered / gap
- 边界路径：covered / gap
- 错误路径：covered / gap
- 回归路径：covered / gap
- 实机路径：covered / skipped / blocked

## 执行证据

- `doctor`：`<result + artifact>`
- `build`：`<result + artifact>`
- `flash`：`<result + artifact or skipped/blocked>`
- `uart exec`：`<commands + transcript artifact>`
- `diag exec`：`<requests + result artifact or not used>`
- `monitor probe/run`：`<items + samples artifact or not used>`
- `verify current`：`<verdict + summary artifact or not used>`
- `report --latest`：`<path>`
- `compare --latest`：`<path or not used>`

## 失败分析

- 失败层：测试设计 / probe 命令 / 源码行为 / 环境或硬件
- 证据：`<artifact/field>`
- 已采取动作：`<actions>`

## 可选生成资产

只有显式使用 task-driven 生成时才包含本节：

- `blackbox_assertions.yaml`：`<path>`
- `unit_test_plan.md`：`<path>`
- `implementation_brief.md`：`<path>`
- `task_snapshot.json`：`<path>`

## 测试质量评价

- 断言是否稳定：是 / 否
- 是否有硬件证据：是 / 否 / blocked
- 是否存在覆盖缺口：`<items>`
- 是否发现不可迁移假设：`<items>`

## 下一步

- `<one concise next step>`
