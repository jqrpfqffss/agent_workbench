# 测试生成与验证流程

用于迁移项目中可由 runtime evidence 验证的 STM32 测试设计。

## 默认 Runtime 测试路径

1. `doctor --json`
2. `scan-project --json`
3. 基于 CLI、diag、monitor 和源码证据设计覆盖矩阵
4. `build --json`
5. 需要实机验证时运行 `flash --json`
6. 针对每个测试点运行 `uart exec`、`diag exec` 或 `monitor probe`
7. `verify current --json` 能有效汇总当前项目时运行
8. `report --latest --json`
9. 回归检查时运行 `compare --latest --json`

## 可选 Task 驱动路径

只有以下情况才使用 `test generate --task <task.yaml>`：

- 用户明确要求 task 驱动生成
- 项目已有成熟匹配 task
- 该仓库里生成资产已知有用

不要为了让 `test generate` 跑起来而默认创建新 task yaml。

## 要读取的证据

- `cli_transcript.log`
- `cli_diag.json`
- `monitor_samples.csv/jsonl`
- `direct_verify_summary.json/md`
- `session_verdict.json`
- `session_brief.md`
- `compare_delta.json`
- `unit.log`，仅当实际执行了 `test run`

## 覆盖审查

每个测试点记录：

- 被测行为
- 触发命令或事件
- 证据来源
- 预期稳定字符串、字段、范围或趋势
- pass/fail/block 结果

## 失败响应

测试失败时：

1. 先检查测试设计是否匹配用户目标
2. 再检查 probe 命令是否真正触发行为
3. 再检查 runtime evidence 是否因为环境阻塞缺失
4. 最后才判断生产代码是否错误
