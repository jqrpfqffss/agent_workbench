# 测试覆盖矩阵

为复杂功能或回归任务生成测试时，使用此矩阵审查覆盖。

| 行为/风险 | 触发方式 | 观察证据 | 断言类型 | 覆盖状态 | 备注 |
|---|---|---|---|---|---|
| `<new_behavior>` | `<cli/diag/event>` | `<transcript/monitor/unit>` | `<cli_contains/monitor/unit>` | covered / gap | `<note>` |

## 最小覆盖要求

### CLI 命令

- help 列出命令。
- 合法命令返回稳定 ack 或 status。
- 非法输入返回错误并恢复 prompt。
- 旧命令至少一个回归探测。

### 外设功能

- control path 被触发。
- status 或 monitor 能观察状态。
- 边界值或非法参数被覆盖。
- reset 后状态符合预期。

### 调试回归

- ready/prompt。
- parser 分类。
- timeout 或 no data 处理。
- compare 差异。

### 协议/诊断

- 合法请求。
- 非法请求。
- 边界长度或字段。
- 错误恢复。

## 质量门槛

- 没有覆盖矩阵时，不要声称复杂测试充分。
- 没有实机证据时，不要声称硬件行为通过。
- 断言只来自 task、当前输出或 evidence。
