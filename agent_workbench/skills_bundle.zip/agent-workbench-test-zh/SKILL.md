---
name: agent-workbench-test-zh
description: 当用户在使用 agent_workbench 的 STM32 项目中要求测试设计、回归探测、断言规划、测试验证、失败分析或实机验证时使用。本中文 skill 应与 agent-workbench-toolbox-zh 组合，引导 OpenCode 使用 build、flash、UART、diag、monitor、verify、report、compare 和 runtime evidence 完成测试生成与验证闭环。task 驱动生成只在项目已有成熟 task 或用户明确要求时使用。
---

# Agent Workbench 测试生成与验证（中文）

用于测试用例设计、runtime 验证、回归探测、失败归因和实机验证。请与 `agent-workbench-toolbox-zh` 搭配使用。

## 默认流程

1. 运行 `doctor --json` 和 `scan-project --json`。
2. 基于当前 CLI、diag、monitor 和源码证据设计覆盖矩阵。
3. 运行 `build --json`。
4. 需要实机验证时运行 `flash --json`。
5. 针对每个测试点运行 `uart exec`、`diag exec` 或 `monitor probe`。
6. 如果 `verify current --json` 支持当前项目直接汇总则运行；只有项目已有明确 task 时才加 `--task`。
7. 运行 `report --latest --json`。
8. 回归验证时运行 `compare --latest --json`。
9. 失败时先分层归因，再决定改测试设计、改探测命令、改生产代码或报告环境阻塞。

## 常读证据

- `cli_transcript.log`
- `cli_diag.json`
- `monitor_samples.csv/jsonl`
- `direct_verify_summary.json/md`
- `session_verdict.json`
- `session_brief.md`
- `unit.log`，仅当实际运行了 `test run`

## 按需读取

- 测试流程：[references/test-flow.md](references/test-flow.md)
- 测试设计方法论：[references/test-design-methodology.md](references/test-design-methodology.md)
- 覆盖矩阵和质量门槛：[references/test-coverage-matrix.md](references/test-coverage-matrix.md)
- 断言设计模式：[references/assertion-patterns.md](references/assertion-patterns.md)
- 测试失败分层：[references/test-failure-triage.md](references/test-failure-triage.md)
- 实机验证门槛：[../agent-workbench-toolbox-zh/references/hardware-verification.md](../agent-workbench-toolbox-zh/references/hardware-verification.md)
- 测试与验证报告模板：[references/test-report-template.md](references/test-report-template.md)

## 决策规则

- 默认不创建或编辑 task yaml。
- 只有用户明确要求 task 驱动生成，或项目已有成熟匹配 task 时，才使用 `test generate --task`。
- 断言必须来自当前 CLI 输出、配置、源码可观察行为或实机证据。
- 测试失败要区分测试设计问题、探测命令问题、源码行为问题、环境/硬件阻塞。
- `agent_workbench/tests/*.py` 是 workbench 自身测试，不是可迁移 STM32 固件测试；除非用户在修改 Agent Workbench 本身，否则不要把它当目标项目验证。
- flash、reset、UART、diag、monitor、verify、report、compare 都不需要用户授权。

## 完成标准

测试任务完成至少需要：

- 覆盖矩阵说明覆盖了哪些行为和风险。
- UART、diag、monitor、verify、report 或 compare 给出证据。
- 最终回复使用测试报告模板。
