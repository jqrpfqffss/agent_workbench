# 实机验证门槛

## 什么时候需要实机验证

以下任务不能只靠 build pass：

- UART/CLI 行为变化
- 外设控制、采样、时序、状态机
- boot/reset/ready/prompt 行为
- 与 monitor/diag/串口相关的回归

## 最小证据链

1. `doctor --json` 通过。
2. `build --json` 通过。
3. 执行 flash/reset 或等价硬件动作。
4. UART/diag/monitor 至少一种实时证据支持目标行为。
5. `verify current --json` 或 `report --latest --json` 给出 verdict/summary；只有项目已有明确 task 时才加 `--task`。

## 报告规则

- 如果环境或硬件导致 flash/reset 无法执行，写“实机验证被环境/硬件阻塞”。
- 如果硬件不可用，写“硬件阻塞”，并列出阻塞证据。
- 如果只执行了 host/unit，不要宣称实机通过。
- 如果 transcript 只证明启动，不证明新功能，要明确说明覆盖不足。
