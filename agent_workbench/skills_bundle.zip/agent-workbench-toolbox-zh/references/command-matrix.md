# 命令矩阵

所有命令默认在项目根目录运行，并尽量加 `--json`：

```powershell
cmd /c ".\agent_workbench.bat <command> --json"
```

## 基础发现

### `doctor --json`

- 场景：每次会话第一步、环境异常、验证前置检查。
- 看字段：`fail_count`、`checks`、`config`、串口/烧录/构建相关字段。
- 成功：`fail_count == 0`。
- 失败后：读 `doctor_report.json/md`，不要继续改代码。

### `scan-project --json`

- 场景：迁移项目、选择源码路径、发现 CLI、查找 task、避免硬编码目录。
- 看字段：源码目录、候选文件、CLI/probe 命令、已有 task、符号/handle。
- 成功：能给出当前项目的真实路径和可用能力。
- 失败后：检查项目根目录和 `agent_workbench.yaml`。

### `context --mode <feature|debug|test> --stage <stage> --json`

- 场景：需要把用户目标、源码和 workbench 证据整理成 OpenCode 可用上下文。
- 看字段：建议读取文件、编辑候选、稳定字符串、验证建议。
- 失败后：先检查 mode/stage 是否支持当前项目。

## 构建与修复

### `build --json`

- 场景：代码修改后、测试前、烧录前。
- 看字段：`exit_code`、`stdout`、`stderr`、log path、artifact path。
- 成功：`exit_code == 0`。
- 失败后：运行 `fix-build --json`，最多三轮。

### `fix-build --json`

- 场景：build 失败后生成结构化修复建议。
- 看字段：`fixes[].file`、`line`、`message`、`suggested_change`。
- 失败后：读 build log，缩小修改范围，不要盲目重构。

## 硬件动作

### `flash --json`

- 场景：构建通过后烧录固件，或验证需要真实板卡运行。
- 看字段：`exit_code`、method、stderr、openocd log。
- 成功：`exit_code == 0`。
- 失败后：读 flash JSON 和 doctor 报告；不要无限重试。

### `reset --json`

- 场景：验证需要明确启动序列，或需要复现 boot/ready/prompt 行为。
- 成功：命令返回成功并能在 UART/diag/monitor 侧看到后续证据。

## UART / diag / monitor

### `uart exec ... --json`

- 场景：验证 ready/prompt、CLI 命令、黑盒行为。
- 推荐模板：`cmd /c ".\agent_workbench.bat uart exec --reset-first --expect-ready --command <cmd> --json"`
- 看字段：transcript、ready/prompt 标记、命令响应、timeout。
- 失败后：读 `cli_transcript.log` 和 `cli_diag.json`。

### `diag exec ... --json`

- 场景：UART CLI 不稳定、需要诊断分类、验证 parser/tx/rx。
- 看字段：classification、rx/tx、parser、timeout、command counters。
- 失败后：按 [failure-routing.md](failure-routing.md) 分类。

### `monitor probe --json` / `monitor run --json`

- 场景：需要运行态变量、趋势、范围、状态机证据。
- 看字段：samples、symbols、timestamp、read errors。
- 失败后：检查符号、probe 配置、目标运行状态。

## 测试与验证

### `test generate --task <task> --json`

- 场景：用户明确要求 task 驱动生成，或项目已有成熟匹配 task。
- 不要把它作为迁移项目的默认测试路径。
- 看字段：generated paths、warnings、task snapshot。
- 必读产物：`blackbox_assertions.yaml`、`unit_test_plan.md`、`implementation_brief.md`。

### `test run --json`

- 场景：运行生成测试或 host/unit 验证。
- 看字段：exit code、unit log、失败断言。

### `verify current --json`

- 场景：功能完成、测试验证、回归确认。
- 只有用户明确要求 task 驱动验证，或项目已有成熟匹配 task 时才加 `--task <task>`。
- 看字段：verdict、summary、assertions、artifact paths。
- 成功：verdict/summary 支持用户目标。

### `report --latest --json`

- 场景：最终报告前收集最新证据。
- 看字段：session path、brief、summary、verdict、artifacts。

### `compare --latest --json`

- 场景：回归对比、修复前后差异、调试归因。
- 看字段：delta、new failures、resolved failures、compare brief。

## Session

### `session debug` / `session feature`

- 场景：需要完整证据包，或要把诊断过程固化成 session。
- 看字段：`session_verdict.json`、`session_brief.md`、`session_summary.md`。
