# OpenCode 四 Skill 编排

## 选择规则

- 用户要新增/修改功能：`toolbox-zh + feature-zh`
- 用户要排查异常/回归：`toolbox-zh + debug-zh`
- 用户要生成/验证测试：`toolbox-zh + test-zh`

不要默认四个 workflow 同时触发。`toolbox-zh` 永远是底层；三类 workflow 通常只选一个主 skill。

## 真实工作流

1. `doctor --json`
2. `scan-project --json`
3. 选择 workflow
4. 基于当前项目选择 runtime probe 和源码阅读范围
5. 执行 build/flash/uart/diag/monitor/verify/report/compare
6. 按 workflow 报告模板输出最终报告

task yaml 不是默认依赖。只有用户明确要求 task 驱动生成，或仓库已有成熟匹配 task 时才使用。

## 项目值来源

OpenCode 必须从这些地方获得项目值：

- `doctor`：串口、ready、prompt、flash、工具链
- `scan-project`：源码路径、CLI、符号、handle、monitor 候选
- `uart exec`：CLI 握手和命令 transcript
- `diag exec`：结构化诊断交换
- `monitor probe/run`：运行态状态和趋势
- `verify current`、`report --latest`、`compare --latest`：汇总证据和回归差异

`agent_workbench/tests/*.py` 是 Agent Workbench 自身测试。除非用户正在修改 Agent Workbench 本身，否则不要把它当目标固件验证。

## 最终报告模板

- 功能开发：`agent-workbench-feature-zh/references/feature-report-template.md`
- 自动调试：`agent-workbench-debug-zh/references/debug-report-template.md`
- 测试生成与验证：`agent-workbench-test-zh/references/test-report-template.md`

未执行实机动作时，必须写成“未执行 / 环境阻塞 / 硬件阻塞”，不能写成通过。
