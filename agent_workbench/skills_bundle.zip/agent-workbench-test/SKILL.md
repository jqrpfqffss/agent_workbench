---
name: agent-workbench-test
description: Use for STM32 test design, runtime verification, regression probes, assertion planning, real-board validation, and failure triage in repositories that use agent_workbench. Combine this with agent-workbench-toolbox to use build, flash, UART, diag, monitor, verify, report, compare, and runtime evidence. Task-driven generation is optional only when the project already uses mature task yaml files or the user explicitly asks for it.
---

# Agent Workbench Test

Use this for test generation and validation workflows. Pair it with `agent-workbench-toolbox`.

This skill is responsible for designing runtime-verifiable tests and separating test-design failures from source, environment, and hardware failures.

## Default Flow

1. Run `doctor --json` and `scan-project --json`.
2. Design the coverage matrix from current CLI, diag, monitor, and source evidence.
3. Run `build --json`.
4. Run `flash --json` when real-board validation matters.
5. Run `uart exec`, `diag exec`, and/or `monitor probe` for each planned test case.
6. Run `verify current --json` when it can summarize the current project directly, or with an existing explicit task only if the project already uses one.
7. Run `report --latest --json`.
8. Run `compare --latest --json` for regression validation.

## Read Next

- Test workflow: [references/test-flow.md](references/test-flow.md)
- Assertion design patterns: [references/assertion-patterns.md](references/assertion-patterns.md)
- Failure triage rules: [references/test-failure-triage.md](references/test-failure-triage.md)
- Detailed test design and coverage guidance: [references/test-design-methodology.md](references/test-design-methodology.md)
- Coverage matrix and quality gates: [references/test-coverage-matrix.md](references/test-coverage-matrix.md)
- Real hardware verification: [../agent-workbench-toolbox/references/hardware-verification.md](../agent-workbench-toolbox/references/hardware-verification.md)
- Test and verification report template: [references/test-report-template.md](references/test-report-template.md)

## Rules

- Do not create or edit task yaml by default.
- Use task-driven `test generate` only when the user explicitly asks for it or the project already has a mature matching task.
- Keep assertions short, deterministic, and machine-readable.
- Use `verify current` when build-only or unit-only evidence is not enough.
- Derive file paths, commands, monitor items, and stable strings from `doctor`, `scan-project`, current source, and runtime evidence instead of copying sample template values.
- Do not use `agent_workbench/tests/*.py` as target-project validation unless the user is modifying Agent Workbench itself; those are workbench self-tests, not portable STM32 firmware tests.
- Do not ask for approval before flash, reset, UART, diag, monitor, verify, report, or compare.
- Use the test report template when summarizing generated cases, coverage, and real-board verification.
