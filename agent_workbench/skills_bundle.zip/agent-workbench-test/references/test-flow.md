# Test Flow

Use this for runtime-verifiable STM32 test design in migrated `agent_workbench` projects.

## Default Runtime Test Path

1. `doctor --json`
2. `scan-project --json`
3. design a coverage matrix from CLI, diag, monitor, and source evidence
4. `build --json`
5. `flash --json` when real-board validation matters
6. run `uart exec`, `diag exec`, or `monitor probe` for each planned test case
7. run `verify current --json` when it summarizes the current project usefully
8. run `report --latest --json`
9. run `compare --latest --json` for regression checks

## Optional Task-Driven Path

Use `test generate --task <task.yaml>` only when:

- the user explicitly asks for task-driven generation
- the project already has a mature matching task
- generated task assets are known to be useful in this repository

Do not create new task yaml files by default just to make `test generate` run.

## Evidence To Read

- `cli_transcript.log`
- `cli_diag.json`
- `monitor_samples.csv/jsonl`
- `direct_verify_summary.json/md`
- `session_verdict.json`
- `session_brief.md`
- `compare_delta.json`
- `unit.log`, only when `test run` was actually executed

## Coverage Review

For every test case, record:

- behavior under test
- trigger command or event
- evidence source
- expected stable string, field, range, or trend
- pass/fail/block result

## Failure Response

If a test fails:

1. check whether the test design matches the user goal
2. check whether the probe command actually triggers the behavior
3. check whether runtime evidence is missing because the environment is blocked
4. only then decide whether production code is wrong
