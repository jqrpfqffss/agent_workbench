# Test And Verification Report Template

Use this structure for final test-design and validation responses.

## Result

- conclusion: pass / fail / partial / blocked
- target behavior: `<behavior>`
- validation mode: runtime evidence / optional task-driven / mixed

## Coverage Summary

- normal path: covered / gap
- boundary path: covered / gap
- error path: covered / gap
- regression path: covered / gap
- real-board path: covered / skipped / blocked

## Executed Evidence

- `doctor`: `<result + artifact>`
- `build`: `<result + artifact>`
- `flash`: `<result + artifact or skipped/blocked>`
- `uart exec`: `<commands + transcript artifact>`
- `diag exec`: `<requests + result artifact or not used>`
- `monitor probe/run`: `<items + samples artifact or not used>`
- `verify current`: `<verdict + summary artifact or not used>`
- `report --latest`: `<path>`
- `compare --latest`: `<path or not used>`

## Failure Analysis

- layer: test design / probe command / source behavior / environment or hardware
- evidence: `<artifact/field>`
- action taken: `<actions>`

## Optional Generated Assets

Only include this section if task-driven generation was explicitly used:

- assertions: `<blackbox_assertions.yaml path>`
- unit plan: `<unit_test_plan.md path>`
- implementation brief: `<implementation_brief.md path>`
- snapshot: `<task_snapshot.json path>`

## Quality Assessment

- stable assertions: yes / no
- hardware evidence: yes / no / blocked
- coverage gaps: `<items>`
- non-portable assumptions found: `<items>`

## Next Step

- `<one concise next step>`
