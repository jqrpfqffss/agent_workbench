---
name: agent-workbench-feature-zh
description: 当用户要在使用 agent_workbench 的 STM32 项目中新增功能、修改功能、扩展 CLI、增加外设控制、实现状态逻辑，或要求“实现并验证”时使用。本中文 skill 应与 agent-workbench-toolbox-zh 组合，用 scan-project、context、build、flash、UART、diag、monitor、verify、report、compare 和 runtime evidence 完成功能开发闭环，默认不依赖 task yaml。
---

# Agent Workbench 功能开发（中文）

用于 STM32 功能开发工作流。请与 `agent-workbench-toolbox-zh` 搭配使用。

本 skill 负责功能开发策略；命令细节和 artifact 语义由 toolbox skill 提供。

## 默认流程

1. 运行 `doctor --json`。
2. 运行 `scan-project --json`。
3. 可用时运行 `context --mode feature --stage implement --json`。
4. 只在当前项目发现到的最小有效源码范围内修改。
5. 运行 `build --json`。
6. 功能涉及实机行为时运行 `flash --json` 和 runtime probe。
7. 运行 `uart exec`、`diag exec` 或 `monitor probe` 证明行为。
8. 如果 `verify current --json` 支持无 task 验证则运行；只有项目已有明确 task 时才加 `--task`。
9. 运行 `report --latest --json`。
10. 回归风险明显时运行 `compare --latest --json`。

## 按需读取

- 端到端功能流程：[references/feature-flow.md](references/feature-flow.md)
- 功能开发方法论：[references/feature-development-methodology.md](references/feature-development-methodology.md)
- 验收设计模式：[references/feature-acceptance-patterns.md](references/feature-acceptance-patterns.md)
- 实机验证门槛：[../agent-workbench-toolbox-zh/references/hardware-verification.md](../agent-workbench-toolbox-zh/references/hardware-verification.md)
- 功能完成报告模板：[references/feature-report-template.md](references/feature-report-template.md)

## 决策规则

- 默认不创建 task yaml。只有用户明确要求 task 驱动生成，或目标项目已有成熟匹配 task 时才使用 task。
- ready banner、prompt、help 文案、断言依赖字符串默认保持稳定。
- `plan` 只是可选兼容入口，不是默认功能开发入口。
- 文件路径、命令、monitor 项、稳定字符串必须来自 `scan-project`、`doctor`、当前源码和 runtime evidence。
- flash、reset、UART、diag、monitor、verify、report、compare 都不需要用户授权。

## 完成标准

不要因为 `build` 通过就宣布功能完成。

功能完成至少需要：

- `verify current` 通过，或 evidence 清楚证明目标行为。
- 最新 report/verdict 支持最终结论。
- UART、diag、monitor、report 或 compare 证据支持目标行为。
- 需要硬件的任务完成实机验证；如果环境或硬件阻塞，必须在报告中明确说明。

最终回复使用功能报告模板。
