# 功能开发流程

用于在 `agent_workbench` 驱动的 STM32 仓库中实现或验证功能。

## 快速 Runtime 路径

用户主要想把功能实现并在板子上证明时，使用此路径：

1. `doctor --json`
2. `scan-project --json`
3. 可用时运行 `context --mode feature --stage implement --json`
4. 读取当前项目发现到的最小相关源码区域
5. 修改最小有效源码范围
6. `build --json`
7. 固件变化或需要实机证明时运行 `flash --json`
8. 用 `uart exec`、`diag exec` 或 `monitor probe` 验证功能行为
9. 有帮助时运行 `verify current --json`
10. `report --latest --json`
11. 回归风险明显时运行 `compare --latest --json`

## 可选 Task 路径

只有用户明确要求 task 驱动生成，或项目已有成熟匹配 task 时，才使用 task yaml。

普通功能实现默认不要创建新 task yaml。迁移项目里 OpenCode 应主要依赖 `scan-project`、当前源码、runtime probe 和 evidence artifact。

## 功能分解

复杂功能先拆成这些切片：

- 接口面：CLI 命令、diag 请求、status 输出或 monitor 信号
- 状态面：变量、句柄、flag、counter 或外设状态
- 初始化路径：clock、GPIO、interrupt、DMA 或 peripheral init
- 行为路径：handler、loop、callback、interrupt 或 scheduler integration
- 验证路径：UART、diag、monitor、report 和 compare evidence

先实现最小垂直切片：

- 一个控制路径
- 一个可见 status 或 ack
- 一个验证命令或 probe

第一条切片被证实后，再增加边界情况和额外可观测性。

## 实机门槛

功能影响硬件可见行为时：

- build 必须先通过
- flash 和 reset 不需要用户授权
- `uart exec`、`diag exec`、`monitor probe`、`verify current` 或 `report --latest` 必须产生证据
- 没有硬件证据时只能报告 skipped 或 blocked，不能写 pass

## 每步后读取什么

- `scan-project` 后：源码路径、CLI 命令、句柄、user code regions、monitor 候选
- 不假设 `Core/Src` 或 `Core/Inc`，用 `scan-project` 发现真实路径
- `context implement` 后：命令返回的推荐文件、约束和实现提示
- `build` 后：build JSON，失败则 `fix-build`
- runtime probe 后：`cli_transcript.log`、`cli_diag.json`、`monitor_samples.*`、latest report/verdict

## 什么时候停止

遇到以下情况停止并报告：

- `doctor` 失败
- `build` 因环境问题失败
- 需要 flash 但环境或硬件阻塞
- UART、diag 或 monitor 不可用导致 runtime evidence 缺失
