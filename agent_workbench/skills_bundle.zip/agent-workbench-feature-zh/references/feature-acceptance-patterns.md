# 功能验收模式

## CLI 可见功能

优先使用：

- 短稳定字符串的 `cli_contains`。
- task 中定义的 `<stable_ack_string_for_new_command>`。
- 能暴露当前值或模式的 status 命令。

避免：

- 大段自然语言输出。
- 时间戳、地址、随机数等不稳定字符串。

## Monitor 驱动功能

运行态重要时加入：

- 人类可读的 status 命令。
- monitor 数值确认。
- 范围或趋势断言，而不是精确瞬时值。

## 状态和控制功能

推荐组合：

- 一个 control 命令。
- 一个 status 命令。
- 一个短 ack 字符串。
- 一个 transcript、diag 或 monitor 证据。

## 稳定字符串

默认保持稳定：

- ready banner
- prompt
- help 标题
- status label
- assertion 使用的 ack 字符串
