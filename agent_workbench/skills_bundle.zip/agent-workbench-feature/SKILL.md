---
name: agent-workbench-feature
description: Use for STM32 feature implementation or feature validation in repositories that use agent_workbench. Combine this with agent-workbench-toolbox to use scan-project, context, build, flash, UART, diag, monitor, verify, report, compare, and runtime evidence to close the feature loop without requiring task yaml by default.
---

# Agent Workbench Feature

Use this for feature development workflows. Pair it with `agent-workbench-toolbox`.

This skill assumes the toolbox skill is responsible for command details and artifact semantics. This skill is responsible for the feature workflow.

## Default Flow

1. Run `doctor`.
2. Run `scan-project`.
3. Run `context --mode feature --stage implement --json` when context support is available.
4. Edit only the smallest valid source scope discovered from the current project.
5. Run `build --json`.
6. Run `flash --json` and runtime probes when real-board behavior matters.
7. Run `uart exec`, `diag exec`, or `monitor probe` to prove the behavior.
8. Run `verify current --json` when it can validate without a task, or with an existing explicit task only if the project already uses one.
9. Run `report --latest --json`.
10. Run `compare --latest --json` only when regression evidence matters.

## Read Next

- End-to-end feature flow: [references/feature-flow.md](references/feature-flow.md)
- Feature development methodology: [references/feature-development-methodology.md](references/feature-development-methodology.md)
- Acceptance design patterns: [references/feature-acceptance-patterns.md](references/feature-acceptance-patterns.md)
- Real hardware verification: [../agent-workbench-toolbox/references/hardware-verification.md](../agent-workbench-toolbox/references/hardware-verification.md)
- Feature completion report template: [references/feature-report-template.md](references/feature-report-template.md)

## Decision Rules

- Do not create task yaml by default. Use tasks only when the user explicitly asks for task-driven generation or a mature matching task already exists in the project.
- Keep ready banner, prompt, help text, and asserted response strings stable unless the feature explicitly changes them.
- Treat `plan` as optional only. Do not use it as the default feature entry point.
- Derive file paths, commands, monitor items, and stable strings from `scan-project`, `doctor`, current source, and runtime evidence instead of reusing template literals.
- Do not ask for approval before flash, reset, UART, diag, monitor, verify, report, or compare.

## Done Criteria

Do not call a feature complete just because `build` passed.

A feature is complete only when:

- `verify current` passes or the evidence shows the requested behavior clearly
- the latest report or verdict supports the claim
- UART, diag, monitor, report, or compare evidence supports the requested behavior
- real-board verification is completed when the feature requires hardware, or explicitly reported as blocked by environment/hardware

Use the feature report template for the final user-facing response after implementation or validation.
