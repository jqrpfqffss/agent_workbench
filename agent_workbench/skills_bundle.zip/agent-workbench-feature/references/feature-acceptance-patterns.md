# Feature Acceptance Patterns

Use these patterns when defining or updating feature acceptance.

## CLI-Visible Features

Prefer:

- `cli_contains` assertions with short stable strings
- explicit ack strings defined by the task, such as `<stable_ack_string_for_new_command>`
- status commands that expose the current value or mode

Avoid:

- vague free-form prose
- multiline outputs that are hard to assert

## Monitor-Driven Features

When runtime state matters, add:

- a status command for human-readable confirmation
- monitor items for numeric confirmation
- range-based or trend-based expectations when exact values may vary slightly

## State And Control Features

Good patterns:

- one control command
- one status command
- one short ack string
- one monitor or transcript check

## Stable Strings

Keep these stable unless the task explicitly changes them:

- ready banner
- prompt
- help headings
- status labels
- ack strings used by assertions
