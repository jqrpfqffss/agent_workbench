# Feature Flow

Use this when implementing or validating a feature in an `agent_workbench` STM32 repo.

## Fast Runtime Path

Use this when the user mainly wants current behavior implemented and proven on the board:

1. `doctor --json`
2. `scan-project --json`
3. `context --mode feature --stage implement --json`, when available
4. read the smallest relevant source regions discovered from the current project
5. edit the smallest valid source scope
6. `build --json`
7. `flash --json` when firmware changed or real-board proof matters
8. `uart exec`, `diag exec`, or `monitor probe` for the feature behavior
9. `verify current --json` when useful for summary
10. `report --latest --json`
11. `compare --latest --json` when regression evidence matters

## Optional Task Path

Use task yaml only when the user explicitly asks for task-driven generation or the project already has a mature matching task.

Do not create a new task yaml by default during normal feature implementation. In most migrated projects, OpenCode should rely on `scan-project`, current source, runtime probes, and evidence artifacts instead.

## Feature Decomposition

For complex features, split the work into these slices before editing:

- interface surface: CLI command, diag request, status output, or monitor signal
- state model: variables, handles, flags, counters, or peripheral state
- initialization path: clocks, GPIO, interrupts, DMA, or peripheral init
- behavior path: handler, loop, callback, interrupt, or scheduler integration
- verification path: UART, diag, monitor, report, and compare evidence

Implement the smallest vertical slice first:

- one control path
- one visible status or ack
- one verification command or probe

Then add boundary cases and extra observability only when the first slice is proven.

## Real-Board Gate

If the feature affects hardware-visible behavior:

- build must pass before flash
- flash and reset do not require user approval in these skills
- `uart exec`, `diag exec`, `monitor probe`, `verify current`, or `report --latest` must produce evidence
- absence of hardware evidence must be reported as skipped or blocked, not as pass

## What To Read After Each Step

- After `scan-project`: source paths, CLI commands, handles, user code regions, monitor candidates
- Use `scan-project` to discover the actual source files for this project instead of assuming `Core/Src` or `Core/Inc`.
- After `context implement`: recommended files, constraints, and implementation hints when the command provides them
- After `build`: build JSON payload, then `fix-build` if needed
- After runtime probes: `cli_transcript.log`, `cli_diag.json`, `monitor_samples.*`, latest report/verdict

## When To Stop

Stop and report blockers when:

- `doctor` fails
- `build` fails for environmental reasons
- flash is required but environment or hardware blocks it
- runtime evidence is missing because UART, diag, or monitor is unavailable
