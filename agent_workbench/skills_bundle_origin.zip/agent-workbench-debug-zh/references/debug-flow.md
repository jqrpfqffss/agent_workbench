# 调试流程

## 快速路径

有 task 时：

```powershell
cmd /c ".\agent_workbench.bat verify current --task <task> --json"
```

然后读取：

- `direct_verify_summary.json`
- `session_verdict.json`
- `cli_diag.json`
- `cli_transcript.log`

适合：回归失败、断言失败、用户只说“这个功能不对”。

## 显式路径

没有 task 或需要重建证据时：

1. `doctor --json`
2. `build --json`
3. `uart exec --json`
4. `diag exec --json`
5. `monitor probe --json`
6. `session debug --json`
7. `report --latest --json`
8. `compare --latest --json`

适合：串口无响应、ready/prompt 缺失、flash 失败、运行态异常。

## 停止条件

- 环境阻塞：doctor fail。
- 硬件阻塞：flash/reset/UART 物理链路失败。
- 信息不足：需要用户授权实机动作。
- 证据互相矛盾：报告矛盾点，提出下一条最小实验。
