---
name: agent-workbench-debug-zh
description: 当用户在使用 agent_workbench 的 STM32 项目中要求调试、排查根因、分析 UART/CLI 无响应、ready 或 prompt 缺失、烧录失败、diag/monitor 异常、运行时异常、断言失败或功能回归时使用。本中文 skill 应与 agent-workbench-toolbox-zh 组合，指导 OpenCode 以 evidence-first 的方式使用 uart exec、diag exec、monitor probe、verify、session debug、report 和 compare 完成自动化调试。
---

# Agent Workbench 自动调试（中文）

用于自动化调试和根因分析。请与 `agent-workbench-toolbox-zh` 搭配使用。

本 skill 的目标是让 OpenCode 先建立证据链，再做最小实验，不要直接猜源码根因。

## 默认流程

### 快速复现路径

1. 运行 `doctor --json`。
2. 如果有 task，运行 `verify current --task <task> --json`。
3. 读取 `direct_verify_summary.json/md` 或 latest report。
4. 根据 verdict 分类失败层。

### 显式调试路径

1. `doctor --json`
2. `build --json`
3. `uart exec ... --json`
4. `diag exec ... --json`
5. `monitor probe --json`，如运行态证据重要
6. `session debug ... --json`
7. `report --latest --json`
8. `compare --latest --json`，如需要回归对比

## 按需读取

- 调试流程：[references/debug-flow.md](references/debug-flow.md)
- 调试方法论：[references/debug-methodology.md](references/debug-methodology.md)
- 调试实验设计：[references/debug-experiment-playbook.md](references/debug-experiment-playbook.md)
- diag 分类码：[references/diag-codes.md](references/diag-codes.md)
- evidence-first 根因排序：[references/evidence-first-root-cause.md](references/evidence-first-root-cause.md)
- 命令 playbook：[references/debug-command-playbook.md](references/debug-command-playbook.md)
- 实机验证门槛：[../agent-workbench-toolbox-zh/references/hardware-verification.md](../agent-workbench-toolbox-zh/references/hardware-verification.md)
- 调试报告模板：[references/debug-report-template.md](references/debug-report-template.md)

## 证据优先级

1. `session_verdict.json`
2. `session_brief.md`
3. `direct_verify_summary.json`
4. `cli_diag.json`
5. `cli_transcript.log`
6. `compare_delta.json`
7. `monitor_samples.csv/jsonl`
8. `doctor_report.json`

## 分类规则

- `rx_zero`：主机没有收到字节，优先查串口、复位、启动、硬件链路。
- `ready_missing`：启动 banner 未出现，优先查固件启动、reset、startup drain。
- `prompt_missing`：有输出但无 prompt，优先查 CLI 生命周期和错误路径。
- `parser_no_command`：输入到达但 parser 没识别，优先查命令结尾、命令表、输入处理。
- `tx_or_host_rx`：发送或主机接收链路异常，优先查 host/driver/串口配置。
- `diag_unavailable`：diag 子系统不可用，退回 UART 和 monitor 建证据。
- flash failure：停止，读 flash/doctor，等待用户处理硬件阻塞。
- assertion regression：先区分 task、测试资产、源码行为、环境层。

## 完成标准

调试完成不是“提出一个猜测”，而是：

- 证据链能支持最可能根因。
- 已执行最小实验验证或排除关键假设。
- 若阻塞，明确阻塞层和下一条最小命令。
- 最终回复使用调试报告模板。
