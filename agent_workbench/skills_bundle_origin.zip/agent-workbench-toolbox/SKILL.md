---
name: agent-workbench-toolbox
description: Use when a repository contains agent_workbench/agent_workbench.yaml and Codex or OpenCode needs the command matrix, artifact map, task yaml contract, or failure routing for STM32 automation workflows. This is the base skill for build, flash, UART, diag, monitor, verify, report, compare, context, and session commands.
---

# Agent Workbench Toolbox

Use this as the base skill for any STM32 repository that is driven by `agent_workbench`.

This skill does not choose a feature, debug, or test strategy by itself. It teaches the agent how to use `agent_workbench` safely and how to read its outputs.

## First Rules

- Treat `agent_workbench` as the primary control plane.
- Prefer `agent_workbench.bat ... --json` over ad-hoc shell pipelines.
- In PowerShell, always invoke batch entry points through `cmd /c`.
- Read structured artifacts before inferring state from source code.

## First Command

Start with:

```powershell
cmd /c ".\agent_workbench.bat doctor --json"
```

Then choose the next command from [references/command-matrix.md](references/command-matrix.md).

## Read Next

Read only the reference file you need:

- Command selection and JSON fields: [references/command-matrix.md](references/command-matrix.md)
- Runtime, evidence, and generated outputs: [references/artifact-map.md](references/artifact-map.md)
- Failure-specific next steps: [references/failure-routing.md](references/failure-routing.md)
- Minimal task yaml contract: [references/task-yaml-minimal.md](references/task-yaml-minimal.md)
- Windows invocation rules: [references/powershell-safe.md](references/powershell-safe.md)
- OpenCode skill orchestration: [references/opencode-orchestration.md](references/opencode-orchestration.md)
- Real hardware verification gate: [references/hardware-verification.md](references/hardware-verification.md)

Always derive project-specific values from the current repository rather than from skill examples:

- use `doctor` for configured ready banner, prompt, flash method, and enabled subsystems
- use `scan-project` for source paths, CLI commands, handles, and existing tasks
- use an existing task yaml or a newly authored minimal task yaml for verify commands and stable strings

## Coordination

- For feature implementation, combine this skill with `agent-workbench-feature`.
- For automated debug, combine this skill with `agent-workbench-debug`.
- For test generation or validation, combine this skill with `agent-workbench-test`.

Those workflow skills should reuse this skill's command and artifact references instead of repeating them.

When OpenCode is unsure which workflow skill to pair with this toolbox, use [references/opencode-orchestration.md](references/opencode-orchestration.md).

## Guardrails

- Always prefer JSON output.
- Do not invent hardware state, UART state, or verification results.
- Stop on environment or hardware blockers and report them explicitly.
- Keep flash and reset as explicit hardware actions that require user approval when appropriate.
- Do not copy example file paths, probe commands, or strings from the skill into a new repository without first replacing them from discovery output.
