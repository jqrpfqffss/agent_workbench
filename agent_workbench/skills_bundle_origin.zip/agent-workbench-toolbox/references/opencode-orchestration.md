# OpenCode Skill Orchestration

Use this file to decide how OpenCode should combine the four Agent Workbench skills.

## Skill Pairing Rule

Always start with `agent-workbench-toolbox`, then add exactly one workflow skill unless the task explicitly spans phases.

Choose:

- `agent-workbench-feature` for implementation, feature modification, CLI command additions, peripheral behavior, or control logic
- `agent-workbench-debug` for failures, smoke checks, root-cause work, UART issues, flash issues, monitor issues, and regressions
- `agent-workbench-test` for test generation, acceptance design, assertion design, test failure triage, and validation asset updates

If a task spans multiple phases, run them sequentially:

1. feature work
2. test generation
3. debug only if verification fails

## First Three Actions

For every new repository:

1. confirm `agent_workbench/agent_workbench.yaml` exists
2. run `doctor`
3. run `scan-project`

Do not assume:

- source layout
- CLI command names
- ready banner or prompt strings
- monitor item names
- flash method
- task yaml path

## Task Path Resolution

Use a task path in this order:

1. user-specified task yaml
2. closest task listed by `scan-project`
3. newly authored minimal task yaml

When creating a new task yaml, write project-specific values discovered from:

- `doctor`
- `scan-project`
- current CLI transcript or evidence
- source ownership discovered in the repository

## Workflow Handoff

### Feature To Test

After feature implementation:

- run `build`
- generate or refresh tests
- run `test run`
- run `verify current`

### Test To Debug

After a test or verify failure:

- classify the failure layer
- use `agent-workbench-debug` only if the failure is not simply a bad task contract or weak generated test asset

### Debug To Feature

After debug evidence points to a source behavior issue:

- return to `agent-workbench-feature`
- patch the smallest owned source area
- rerun the failing verification path

## Quality Bar For Claiming Success

OpenCode may claim success only when:

- build passed
- task-specific verification passed or the evidence clearly proves the target behavior
- hardware actions were either completed with evidence or explicitly skipped with a stated reason
- final answer cites the concrete artifacts used

Use the workflow-specific report template:

- feature work: `agent-workbench-feature/references/feature-report-template.md`
- debug work: `agent-workbench-debug/references/debug-report-template.md`
- test work: `agent-workbench-test/references/test-report-template.md`

## Quality Bar For Reporting Failure

OpenCode should report failure with:

- failure layer
- strongest evidence
- next smallest action
- artifact paths

Avoid broad source theories without evidence.
