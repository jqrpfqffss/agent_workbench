# Minimal Task YAML Contract

Use this contract when no existing task yaml matches the user's request closely enough.

## Required Shape

```yaml
id: replace_with_task_id
mode: feature
goal: One sentence describing the intended outcome.
scope:
  include:
    - <source_file_from_scan_project>
  exclude:
    - Drivers
acceptance:
  blackbox:
    - name: behavior_check
      type: cli_contains
      needle: "<stable_ack_string>"
  unit:
    - one concise unit or host-test expectation for the behavior
observability:
  notes:
    - keep the configured ready banner stable
verify:
  sequence:
    - doctor
    - build
    - test
    - debug
  cli_commands:
    - <probe_command_from_task_or_scan_project>
implementation:
  read_candidates:
    - <source_file_from_scan_project>
  edit_candidates:
    - <source_file_from_scan_project>
  stable_strings:
    - "<ready_banner_from_doctor_or_config>"
    - "<prompt_from_doctor_or_config>"
  max_edit_files: 1
```

## Field Guidance

### `id`

- Lowercase with underscores is safest.
- Keep it stable across reruns so generated assets land in one task folder.

### `mode`

- Use `feature` for development or behavior validation.
- Use `debug` only for explicit diagnostic tasks.

### `goal`

- One short sentence.
- Describe the behavior, not the implementation trick.

### `scope.include`

- List the smallest set of source files that may matter.
- Prefer concrete paths over directories when you already know them.
- Populate these paths from `scan-project`, not from skill examples.

### `scope.exclude`

- Keep `Drivers` excluded unless the task explicitly requires it.

### `acceptance.blackbox`

- Prefer machine-readable CLI, monitor, or file assertions.
- Keep strings short and stable.

### `acceptance.unit`

- Write human-readable unit expectations even if host tests are still lightweight.

### `observability.notes`

- Record strings or signals that must stay stable for automation.

### `verify.sequence`

- Default to:
  - `doctor`
  - `build`
  - `test`
  - `debug`

### `verify.cli_commands`

- Include the exact commands needed for smoke or behavior validation.
- Prefer commands already visible in:
  - existing task yaml files
  - `scan-project` output under `details.uart.probe_commands`
  - the feature's own control and status surface

### `implementation.read_candidates`

- Smallest set of files the workflow should read first.

### `implementation.edit_candidates`

- Smallest set of files the workflow may edit.

### `implementation.stable_strings`

- Include the ready banner, prompt, help text, and any strings used in assertions.
- Copy these from the current repository's config, task contract, and existing CLI output, not from a sample repository.

### `implementation.max_edit_files`

- Keep this tight.
- Use `1` or `2` when possible.

## When To Create A New Task

Create a new task yaml when:

- no existing task matches the requested behavior
- the user wants a reusable validation contract
- the feature or test flow needs generated assets

Prefer reusing an existing task when:

- the task goal is already close
- only command lists or a few acceptance strings need adjustment
