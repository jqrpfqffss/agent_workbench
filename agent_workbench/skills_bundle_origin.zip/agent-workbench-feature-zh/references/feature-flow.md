# 功能开发流程

## 标准路径

1. `doctor --json`
2. `scan-project --json`
3. 查找已有 task
4. 必要时创建 task yaml
5. `context --mode feature --stage implement --task <task> --json`
6. 读取候选源码
7. 最小范围修改
8. `build --json`
9. `test generate --task <task> --json`
10. `test run --json`
11. `verify current --task <task> --json`
12. `report --latest --json`
13. 必要时 `compare --latest --json`

## 选择 task

优先级：

1. 用户明确指定的 task。
2. `scan-project` 发现的相近 task。
3. 根据当前需求新建最小 task。

不要因为找不到 task 就退回纯源码修改；复杂功能必须先落成可验证契约。

## 修改边界

- 先读 `implementation.read_candidates`。
- 只改 `implementation.edit_candidates`。
- 超过 `max_edit_files` 时先重新确认 task。
- 不假设 `Core/Src` 或 `Core/Inc`，用 `scan-project` 发现真实路径。

## 验证闭环

- build：只证明能编译。
- test generate/run：证明测试资产能生成并运行。
- verify current：证明当前行为符合 task。
- report/compare：提供用户可审计证据。
