# 功能 Task 编写

## 编写步骤

1. 用一句话写 `goal`。
2. 用 `scan-project` 填 `scope.include`。
3. 写最少的 `acceptance.blackbox`。
4. 写 `verify.cli_commands`，必须能触发或观察功能。
5. 写 `implementation.read_candidates` 和 `edit_candidates`。
6. 写 `stable_strings`，包括 ready、prompt、help/status/ack 字符串。

## 验收建议

- 新 CLI 命令：断言 help 列出命令、命令执行有稳定 ack、status 能看到状态。
- 外设功能：CLI 证明控制面，monitor/diag 证明运行态。
- 状态功能：至少一个设置命令和一个查询命令。
- 协议功能：覆盖合法输入、非法输入、边界输入、prompt 恢复。

## 常见错误

- task goal 写成“修改某文件”，而不是“实现某行为”。
- acceptance 字符串来自想象，不来自当前 CLI 或新需求契约。
- scope 过大，导致 OpenCode 修改太多文件。
- verify 命令不能真正触发新行为。
