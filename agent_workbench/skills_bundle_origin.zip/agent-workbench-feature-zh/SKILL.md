---
name: agent-workbench-feature-zh
description: 当用户要在使用 agent_workbench 的 STM32 项目中新增功能、修改功能、扩展 CLI、增加外设控制、实现状态逻辑，或要求“实现并验证”时使用。本中文 skill 应与 agent-workbench-toolbox-zh 组合，用 task yaml、context、build、test generate、test run、verify、report 和 compare 完成功能开发闭环。
---

# Agent Workbench 功能开发（中文）

用于 STM32 功能开发工作流。请与 `agent-workbench-toolbox-zh` 搭配使用。

本 skill 负责功能开发策略；命令细节和 artifact 语义由 toolbox skill 提供。

## 默认流程

1. 运行 `doctor --json`。
2. 运行 `scan-project --json`。
3. 复用最接近的 task yaml；没有合适 task 时创建最小 task。
4. 运行 `context --mode feature --stage implement --task <task.yaml> --json`。
5. 只在最小有效源码范围内修改。
6. 运行 `build --json`。
7. 运行 `test generate --task <task.yaml> --json`。
8. 运行 `test run --json`。
9. 运行 `verify current --task <task.yaml> --json`。
10. 运行 `report --latest --json`。
11. 回归风险明显时运行 `compare --latest --json`。

## 按需读取

- 端到端功能流程：[references/feature-flow.md](references/feature-flow.md)
- 功能开发方法论：[references/feature-development-methodology.md](references/feature-development-methodology.md)
- task yaml 编写规则：[references/task-authoring-for-feature.md](references/task-authoring-for-feature.md)
- 验收设计模式：[references/feature-acceptance-patterns.md](references/feature-acceptance-patterns.md)
- 实机验证门槛：[../agent-workbench-toolbox-zh/references/hardware-verification.md](../agent-workbench-toolbox-zh/references/hardware-verification.md)
- 功能完成报告模板：[references/feature-report-template.md](references/feature-report-template.md)
- 可复用 task 模板：[assets/task-templates](assets/task-templates)

## 决策规则

- 已有 task 目标足够接近时，优先复用。
- 新功能需要长期回归验证时，创建新的最小 task。
- ready banner、prompt、help 文案、断言依赖字符串默认保持稳定。
- `plan` 只是可选兼容入口，不是默认功能开发入口。
- 文件路径、命令、稳定字符串必须来自 `scan-project`、`doctor`、当前 task 或当前源码。

## 完成标准

不要因为 `build` 通过就宣布功能完成。

功能完成至少需要：

- `verify current` 通过，或 evidence 清楚证明目标行为。
- 最新 report/verdict 支持最终结论。
- 生成的断言与任务意图一致。
- 需要硬件的任务完成实机验证；如果未授权或被阻塞，必须在报告中明确说明。

最终回复使用功能报告模板。
