---
name: agent-workbench-feature
description: Use for STM32 feature implementation or feature validation in repositories that use agent_workbench. Combine this with agent-workbench-toolbox to choose tasks, create minimal task yaml files, run build and verify loops, and close the feature with generated evidence.
---

# Agent Workbench Feature

Use this for feature development workflows. Pair it with `agent-workbench-toolbox`.

This skill assumes the toolbox skill is responsible for command details and artifact semantics. This skill is responsible for the feature workflow.

## Default Flow

1. Run `doctor`.
2. Run `scan-project`.
3. Reuse the closest task yaml, or create a minimal new one.
4. Run `context --mode feature --stage implement --task <task.yaml> --json`.
5. Edit only the smallest valid source scope.
6. Run `build`.
7. Run `test generate --task <task.yaml>`.
8. Run `test run`.
9. Run `verify current --task <task.yaml>`.
10. Run `report --latest`.
11. Run `compare --latest` only when regression evidence matters.

## Read Next

- End-to-end feature flow: [references/feature-flow.md](references/feature-flow.md)
- Feature development methodology: [references/feature-development-methodology.md](references/feature-development-methodology.md)
- Authoring or updating task yaml files: [references/task-authoring-for-feature.md](references/task-authoring-for-feature.md)
- Acceptance design patterns: [references/feature-acceptance-patterns.md](references/feature-acceptance-patterns.md)
- Real hardware verification: [../agent-workbench-toolbox/references/hardware-verification.md](../agent-workbench-toolbox/references/hardware-verification.md)
- Feature completion report template: [references/feature-report-template.md](references/feature-report-template.md)
- Reusable task starters: [assets/task-templates](assets/task-templates)

## Decision Rules

- Prefer an existing task when the goal already matches closely.
- Create a new minimal task when the request introduces a new reusable feature contract.
- Keep ready banner, prompt, help text, and asserted response strings stable unless the task explicitly changes them.
- Treat `plan` as optional only. Do not use it as the default feature entry point.
- Derive file paths, commands, and stable strings from `scan-project`, `doctor`, and current task assets instead of reusing template literals.

## Done Criteria

Do not call a feature complete just because `build` passed.

A feature is complete only when:

- `verify current` passes or the evidence shows the requested behavior clearly
- the latest report or verdict supports the claim
- any task-generated assertions still align with the intended behavior
- real-board verification is completed when the task requires hardware, or explicitly reported as pending approval or blocked

Use the feature report template for the final user-facing response after implementation or validation.
