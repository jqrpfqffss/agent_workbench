# Feature Flow

Use this when implementing or validating a feature in an `agent_workbench` STM32 repo.

## Fast Path

If a matching task already exists and the user mainly wants to validate current behavior:

1. `doctor`
2. `verify current --task <task.yaml>`
3. `report --latest`

## Full Implementation Path

1. `doctor`
2. `scan-project`
3. Pick the closest task yaml under `agent_workbench/tasks/`
4. If no task is close enough, create a minimal new task yaml
5. `context --mode feature --stage implement --task <task.yaml>`
6. Read the generated implementation brief and constraints
7. Edit only the scoped source files
8. `build`
9. `test generate --task <task.yaml>`
10. `test run`
11. `verify current --task <task.yaml>`
12. `report --latest`
13. `compare --latest` if regression evidence is important

## Feature Decomposition

For complex features, split the work into these slices before editing:

- interface surface: CLI command, diag request, status output, or monitor signal
- state model: variables, handles, flags, counters, or peripheral state
- initialization path: clocks, GPIO, interrupts, DMA, or peripheral init
- behavior path: handler, loop, callback, interrupt, or scheduler integration
- verification path: task yaml acceptance, generated tests, real-board probes

Implement the smallest vertical slice first:

- one control path
- one visible status or ack
- one verification command or probe

Then add boundary cases and extra observability only when the first slice is proven.

## Real-Board Gate

If the feature affects hardware-visible behavior:

- build must pass before flash
- flash or reset requires approval
- `verify current` or an explicit UART, diag, or monitor command must produce evidence
- absence of hardware evidence must be reported as pending or blocked, not as pass

## What To Read After Each Step

- After `scan-project`: task list, CLI commands, handles, user code regions
- Use `scan-project` to discover the actual source files for this project instead of assuming `Core/Src` or `Core/Inc`.
- After `context implement`: generated `implementation_brief.md`, `*_constraints.json`, and the allowed read/edit set
- After `build`: build JSON payload, then `fix-build` if needed
- After `verify current`: `direct_verify_summary.json`, then latest `session_verdict.json`

## When To Stop

Stop and report blockers when:

- `doctor` fails
- `build` fails for environmental reasons
- flash is required but not approved
- `verify current` is blocked by hardware or environment state
