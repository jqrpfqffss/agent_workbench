# Task Authoring For Feature Work

Create a new task yaml only when an existing one is not close enough.

## Minimum Fields

Use the minimal contract from `agent-workbench-toolbox/references/task-yaml-minimal.md` and tailor these fields:

- `id`
- `mode: feature`
- `goal`
- `scope.include`
- `acceptance.blackbox`
- `acceptance.unit`
- `observability.notes`
- `verify.cli_commands`
- `implementation.read_candidates`
- `implementation.edit_candidates`
- `implementation.stable_strings`
- `implementation.max_edit_files`

## Feature Task Writing Rules

- Write the goal as user-visible behavior.
- Put likely edited files in `scope.include`.
- Derive those files from `scan-project` output, existing tasks, and current module ownership rather than from a fixed directory layout.
- Keep `Drivers` in `scope.exclude` unless truly needed.
- Put smoke commands in `verify.cli_commands`.
- Derive smoke commands from the feature's control and status path, existing CLI surface, or diagnostic surface.
- Include any assertion strings that must not drift in `implementation.stable_strings`.

## When Reusing An Existing Task

Reuse a task when:

- its goal already matches the requested behavior
- only one or two CLI commands or acceptance strings need extension

Create a new task when:

- the behavior introduces a new feature contract
- the validation path is materially different
- you want dedicated generated test assets for later reuse
