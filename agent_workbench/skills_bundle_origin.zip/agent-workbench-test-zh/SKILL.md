---
name: agent-workbench-test-zh
description: 当用户在使用 agent_workbench 的 STM32 项目中要求生成测试用例、设计回归测试、编写断言、验证测试、分析测试失败、执行实机验证，或希望基于 task yaml 生成 blackbox/unit/monitor 测试资产时使用。本中文 skill 应与 agent-workbench-toolbox-zh 组合，引导 OpenCode 完成 task、test generate、test run、verify current、report 的测试生成与验证闭环。
---

# Agent Workbench 测试生成与验证（中文）

用于测试用例生成、测试资产修正、回归验证和实机验证。请与 `agent-workbench-toolbox-zh` 搭配使用。

## 默认流程

1. 选择或创建 task yaml。
2. 运行 `test generate --task <task.yaml> --json`。
3. 读取生成产物。
4. 审查覆盖矩阵和断言质量。
5. 运行 `test run --json`。
6. 必要时运行 `verify current --task <task.yaml> --json`。
7. 运行 `report --latest --json`。
8. 失败时先分层归因，再决定改 task、regenerate、改测试资产或改生产代码。

## 必读产物

- `blackbox_assertions.yaml`
- `unit_test_plan.md`
- `implementation_brief.md`
- `task_snapshot.json`
- `unit.log`

## 按需读取

- 测试流程：[references/test-flow.md](references/test-flow.md)
- 测试设计方法论：[references/test-design-methodology.md](references/test-design-methodology.md)
- 覆盖矩阵和质量门槛：[references/test-coverage-matrix.md](references/test-coverage-matrix.md)
- 断言设计模式：[references/assertion-patterns.md](references/assertion-patterns.md)
- 测试失败分层：[references/test-failure-triage.md](references/test-failure-triage.md)
- 实机验证门槛：[../agent-workbench-toolbox-zh/references/hardware-verification.md](../agent-workbench-toolbox-zh/references/hardware-verification.md)
- 测试与验证报告模板：[references/test-report-template.md](references/test-report-template.md)
- 可复用 task 模板：[assets/task-templates](assets/task-templates)

## 决策规则

- acceptance 不清楚时，先改 task yaml，不要先改生产代码。
- task yaml 修改后必须 regenerate。
- 断言必须来自当前 CLI 输出、配置、task contract 或实机证据。
- 测试失败要区分 task 问题、生成资产问题、源码行为问题、环境阻塞。
- 实机验证未执行时，报告必须写明未执行或等待授权。

## 完成标准

测试任务完成至少需要：

- task contract 清晰。
- 生成资产存在且与 task 一致。
- 覆盖矩阵说明覆盖了哪些行为和风险。
- `test run` 或 `verify current` 给出证据。
- 最终回复使用测试报告模板。
