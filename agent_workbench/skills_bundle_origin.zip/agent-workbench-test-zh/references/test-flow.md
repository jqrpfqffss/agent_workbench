# 测试生成与验证流程

## 标准路径

1. `doctor --json`
2. `scan-project --json`
3. 选择或创建 task yaml
4. `test generate --task <task> --json`
5. 读取生成资产
6. 审查覆盖矩阵
7. `test run --json`
8. `verify current --task <task> --json`
9. `report --latest --json`
10. 必要时 `compare --latest --json`

## 生成后必须检查

- `blackbox_assertions.yaml` 是否覆盖目标行为。
- `unit_test_plan.md` 是否覆盖 host/unit 可测逻辑。
- `implementation_brief.md` 是否与真实修改范围一致。
- `task_snapshot.json` 是否反映当前 task。

## 修复顺序

1. task contract 不清楚：改 task。
2. 断言太弱/太强：改 task 或生成资产，再 regenerate。
3. 源码行为不符合验收：改生产代码。
4. 环境阻塞：停止并报告。
