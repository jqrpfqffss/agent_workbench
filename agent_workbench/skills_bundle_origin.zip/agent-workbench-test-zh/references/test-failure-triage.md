# 测试失败分层

## 四层归因

### 1. Task contract 问题

表现：

- goal 模糊。
- acceptance 与用户意图不一致。
- cli_commands 不能触发行为。

动作：先改 task yaml，再 regenerate。

### 2. 生成资产问题

表现：

- 断言太弱，没有覆盖目标。
- 断言太强，匹配不稳定输出。
- unit plan 与代码结构不匹配。

动作：改 task 或生成资产，再 rerun。

### 3. 源码行为问题

表现：

- task 和断言合理。
- transcript/monitor 证明行为不符合验收。

动作：修改生产代码，然后 build/test/verify。

### 4. 环境阻塞

表现：

- doctor fail。
- flash fail。
- UART 无数据。
- monitor 无法采样。

动作：停止并报告阻塞，不把它写成测试失败。

## 决策顺序

先问：

1. task 是否正确描述目标？
2. 生成资产是否正确验证目标？
3. 运行证据是否稳定？
4. 源码是否真的不符合？

最后才改生产代码。
