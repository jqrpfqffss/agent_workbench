# 测试生成与验证报告模板

最终回复按此结构生成。

## 测试结果

- 结论：通过 / 失败 / 部分通过 / 阻塞
- task：`<task path>`
- 目标：`<goal>`

## 生成资产

- `blackbox_assertions.yaml`：`<path>`
- `unit_test_plan.md`：`<path>`
- `implementation_brief.md`：`<path>`
- `task_snapshot.json`：`<path>`

## 覆盖摘要

- 正常路径：covered / gap
- 边界路径：covered / gap
- 错误路径：covered / gap
- 回归路径：covered / gap
- 实机路径：covered / pending / blocked

## 执行证据

- `test run`：`<result + artifact>`
- `verify current`：`<verdict + summary>`
- `uart/diag/monitor`：`<evidence or not run>`
- `report --latest`：`<path>`
- `compare --latest`：`<path or not run>`

## 失败分析

- 失败层：task / generated assets / source behavior / environment
- 证据：`<artifact/field>`
- 已采取修复：`<actions>`

## 测试质量评价

- 断言是否稳定：是 / 否
- 是否有硬件证据：是 / 否 / 等待授权
- 是否存在覆盖缺口：`<items>`

## 下一步

- `<one concise next step>`
