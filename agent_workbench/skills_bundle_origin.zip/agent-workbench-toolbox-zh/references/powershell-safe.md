# PowerShell 安全调用

## 基本格式

在 PowerShell 中调用 bat：

```powershell
cmd /c ".\agent_workbench.bat doctor --json"
```

## 规则

- 一次只运行一条命令。
- 不要用 `;`、`&&`、`||` 串联 workbench 命令。
- 路径含空格时加双引号。
- 优先使用相对项目根目录的 `.\agent_workbench.bat`。
- 每条命令都尽量加 `--json`。
- 依赖上一条 JSON 输出决定下一条动作。

## 硬件动作

以下命令需要用户授权：

- `flash`
- `reset`
- 任何会让目标板复位或改变硬件状态的验证命令

## 不推荐

```powershell
.\agent_workbench.bat build --json; .\agent_workbench.bat flash --json
```

推荐拆开运行，并检查每次 JSON 结果。
