# 最小 Task YAML 契约

没有合适 task 时，创建最小 task yaml。字段名保持英文，内容可中文或英文，但稳定字符串必须来自当前项目。

```yaml
id: replace_with_task_id
mode: feature
goal: 用一句话描述目标行为。
scope:
  include:
    - <source_file_from_scan_project>
  exclude:
    - Drivers
acceptance:
  blackbox:
    - name: behavior_check
      type: cli_contains
      needle: "<stable_ack_or_status_string>"
  unit:
    - 用一句话描述 host/unit 层期望
observability:
  notes:
    - 保持当前项目配置的 ready banner 和 prompt 稳定
verify:
  sequence:
    - doctor
    - build
    - test
    - debug
  cli_commands:
    - <probe_command_from_task_or_scan_project>
implementation:
  read_candidates:
    - <source_file_from_scan_project>
  edit_candidates:
    - <source_file_from_scan_project>
  stable_strings:
    - "<ready_banner_from_doctor_or_config>"
    - "<prompt_from_doctor_or_config>"
  max_edit_files: 1
```

## 字段规则

- `id`：小写、下划线、稳定；同一任务反复生成资产时不要改。
- `goal`：写行为目标，不写实现手段。
- `scope.include`：来自 `scan-project`，不要写示例路径。
- `scope.exclude`：默认排除依赖库和生成目录。
- `acceptance.blackbox`：优先短而稳定的 CLI/monitor/file 断言。
- `verify.cli_commands`：来自现有 CLI、task 或 scan-project 的 probe 命令。
- `implementation.edit_candidates`：越小越好；超过 `max_edit_files` 要重新确认任务边界。
