# 实机验证门槛

## 什么时候需要实机验证

以下任务不能只靠 build pass：

- UART/CLI 行为变化
- 外设控制、采样、时序、状态机
- boot/reset/ready/prompt 行为
- 与 monitor/diag/串口相关的回归

## 最小证据链

1. `doctor --json` 通过。
2. `build --json` 通过。
3. 用户授权后执行 flash/reset 或等价硬件动作。
4. UART/diag/monitor 至少一种实时证据支持目标行为。
5. `verify current --task <task> --json` 或 `report --latest --json` 给出 verdict/summary。

## 报告规则

- 如果用户未授权 flash/reset，写“实机验证等待用户授权”。
- 如果硬件不可用，写“硬件阻塞”，并列出阻塞证据。
- 如果只执行了 host/unit，不要宣称实机通过。
- 如果 transcript 只证明启动，不证明新功能，要明确说明覆盖不足。
