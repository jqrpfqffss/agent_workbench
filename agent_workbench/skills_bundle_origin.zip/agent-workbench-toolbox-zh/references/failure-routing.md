# 失败路由

失败后先分类，再行动。不要看到失败就直接改源码。

## build fail

- 先读：`build --json`、build log。
- 下一步：`fix-build --json`。
- 只有修复建议和源码上下文一致时才 edit。
- 三轮仍失败，停止并报告剩余错误。

## flash fail

- 先读：flash JSON、OpenOCD/stlink stderr、`doctor_report.json`。
- 下一步：确认探针、目标供电、flash method。
- 不要自动反复烧录。

## ready missing

- 先读：`cli_transcript.log`、`cli_diag.json`、`doctor_report.json`。
- 下一步：确认 reset、startup drain、UART 配置、固件是否启动。
- 如果 `rx_zero`，优先排硬件/串口/复位链路。

## prompt missing

- 先读：transcript 是否已有输出但无 prompt。
- 下一步：检查 CLI 生命周期、命令循环、错误路径是否返回 prompt。

## parser fail / `parser_no_command`

- 先读：`cli_diag.json` 的 parser 分类和 transcript。
- 下一步：确认命令结尾、命令表、输入处理、大小写/空格规则。

## monitor no data

- 先读：monitor JSON、symbols、read error。
- 下一步：确认目标在运行、符号存在、probe 配置正确。

## assertion fail

- 先读：`direct_verify_summary.json`、`blackbox_assertions.yaml`、transcript。
- 判断层次：
  - task contract 写错
  - 生成资产太弱或太强
  - 源码行为不符合验收
  - 环境/硬件阻塞
- 先修 task 或测试资产，再考虑生产代码。

## diag unavailable

- 先读：doctor 是否启用 diag_uart，串口配置是否存在。
- 下一步：退回 `uart exec` 和 `monitor probe` 建证据链。
