# OpenCode 四 Skill 编排

## 选择规则

- 用户要新增/修改功能：`toolbox-zh + feature-zh`
- 用户要排查异常/回归：`toolbox-zh + debug-zh`
- 用户要生成/验证测试：`toolbox-zh + test-zh`

不要默认四个 workflow 同时触发。`toolbox-zh` 永远是底层；三类 workflow 通常只选一个主 skill。

## 真实工作流

1. `doctor --json`
2. `scan-project --json`
3. 选择 workflow
4. 选择或创建 task yaml
5. 执行 build/test/verify/debug/report
6. 按 workflow 报告模板输出最终报告

## 项目值来源

OpenCode 必须从这些地方获得项目值：

- `doctor`：串口、ready、prompt、flash、工具链。
- `scan-project`：源码路径、CLI、task、符号、handle。
- task yaml：目标、验收、命令、稳定字符串、编辑边界。
- evidence：transcript、diag、monitor、verdict、compare。

不要把 skill 文件中的占位符或示例值当作项目事实。

## 最终报告模板

- 功能开发：`agent-workbench-feature-zh/references/feature-report-template.md`
- 自动调试：`agent-workbench-debug-zh/references/debug-report-template.md`
- 测试生成与验证：`agent-workbench-test-zh/references/test-report-template.md`

未执行实机动作时，必须写成“未执行 / 等待授权 / 被阻塞”，不能写成通过。
