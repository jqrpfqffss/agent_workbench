# 产物地图

优先读机器可解析 JSON，再读 Markdown brief，最后读长日志。

## 高优先级

- `session_verdict.json`：一次 session 的最终 verdict、失败层、断言摘要。
- `direct_verify_summary.json`：`verify current` 的直接摘要。
- `cli_diag.json`：UART/CLI 诊断分类和 rx/tx/parser 指标。
- `compare_delta.json`：与上一轮或基线相比的差异。
- `doctor_report.json`：环境、配置、工具链、串口、烧录器状态。

## 面向报告

- `session_brief.md`：适合最终回复引用的短证据。
- `session_summary.md`：完整 session 摘要。
- `direct_verify_summary.md`：verify 的可读摘要。
- `compare_brief.md`：回归差异的人类可读说明。

## 原始证据

- `cli_transcript.log`：UART 命令交互原文。
- `monitor_samples.csv/jsonl`：monitor 采样结果。
- `unit.log`：host/unit/test run 日志。
- `commands.log`：session 内执行过的命令。

## 生成资产

位于 `generated/tasks/<task_id>/...`：

- `blackbox_assertions.yaml`：黑盒断言。
- `unit_test_plan.md`：unit/host 测试计划。
- `implementation_brief.md`：实现相关简报。
- `task_snapshot.json`：生成时的 task 快照。

## 读取顺序

1. verdict/summary JSON。
2. brief Markdown。
3. transcript / unit / monitor 原始证据。
4. 只有证据不足时再扩大源码阅读范围。
