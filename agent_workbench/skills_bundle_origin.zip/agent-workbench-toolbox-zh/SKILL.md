---
name: agent-workbench-toolbox-zh
description: 当仓库包含 agent_workbench/agent_workbench.yaml，且 Codex 或 OpenCode 需要使用中文说明来调用 agent_workbench 的编译、烧录、UART、diag_uart、monitor、verify、report、compare、context、session、task yaml、证据产物或失败路由时使用。本 skill 是 STM32 自动化功能开发、自动化调试、测试生成与实机验证的中文底层工具 skill。
---

# Agent Workbench 工具箱（中文）

把本 skill 作为所有 `agent_workbench` 驱动 STM32 仓库的底层工具适配层。

本 skill 不替 OpenCode 选择“功能开发 / 调试 / 测试”的策略；它负责告诉 OpenCode 如何安全调用 `agent_workbench`，如何读取 JSON 输出和 evidence artifact。

## 第一原则

- 把 `agent_workbench` 当作主控制面，而不是临时脚本集合。
- 优先调用 `agent_workbench.bat ... --json`，避免随手拼 shell 管道。
- 在 PowerShell 中调用 bat 入口时始终使用 `cmd /c`。
- 先读结构化 JSON 和 evidence，再从源码推断状态。
- 不要从 skill 示例复制路径、串口、prompt、ready banner 或探测命令到新项目。

## 第一条命令

从环境自检开始：

```powershell
cmd /c ".\agent_workbench.bat doctor --json"
```

然后根据 [references/command-matrix.md](references/command-matrix.md) 选择下一条命令。

## 按需读取

只读取当前任务需要的 reference：

- 命令选择、调用模板、关键 JSON 字段：[references/command-matrix.md](references/command-matrix.md)
- runtime、evidence、generated 产物地图：[references/artifact-map.md](references/artifact-map.md)
- 失败类型到下一步动作的路由：[references/failure-routing.md](references/failure-routing.md)
- 最小 task yaml 契约：[references/task-yaml-minimal.md](references/task-yaml-minimal.md)
- Windows / PowerShell 安全调用规则：[references/powershell-safe.md](references/powershell-safe.md)
- OpenCode 四 skill 编排规则：[references/opencode-orchestration.md](references/opencode-orchestration.md)
- 实机验证门槛：[references/hardware-verification.md](references/hardware-verification.md)

所有项目相关值必须来自当前仓库：

- 用 `doctor` 获取 ready banner、prompt、flash 方法、已启用子系统。
- 用 `scan-project` 获取源码路径、CLI 命令、句柄、已有 task。
- 用已有 task yaml 或新建最小 task yaml 提供 verify 命令和稳定字符串。

## 协作规则

- 功能开发：组合 `agent-workbench-toolbox-zh` + `agent-workbench-feature-zh`。
- 自动调试：组合 `agent-workbench-toolbox-zh` + `agent-workbench-debug-zh`。
- 测试生成与验证：组合 `agent-workbench-toolbox-zh` + `agent-workbench-test-zh`。

workflow skill 不应重复解释全部命令细节，应复用本 skill 的 command、artifact 和 failure reference。

OpenCode 不确定该搭配哪个 workflow skill 时，读取 [references/opencode-orchestration.md](references/opencode-orchestration.md)。

## 防护栏

- 始终优先使用 JSON 输出。
- 不要捏造硬件状态、UART 状态或验证结果。
- 环境或硬件阻塞时停止并明确报告。
- flash / reset 是硬件动作，需要用户授权。
- 迁移到其他项目时，不要复用示例路径、探测命令或字符串，必须从 discovery 输出替换。
