---
name: agent-workbench-test
description: Use for task-driven STM32 test generation, generated asset review, test execution, verify loops, and failure triage in repositories that use agent_workbench. Combine this with agent-workbench-toolbox for command and artifact details.
---

# Agent Workbench Test

Use this for test generation and validation workflows. Pair it with `agent-workbench-toolbox`.

This skill is responsible for deciding how to create or refine task-driven validation assets and how to separate task-definition failures from source failures.

## Default Flow

1. Choose or create the task yaml.
2. Run `test generate --task <task.yaml>`.
3. Read the generated test assets.
4. Run `test run`.
5. Run `verify current --task <task.yaml>` when end-to-end behavior matters.
6. Run `report --latest`.

## Read Next

- Test workflow: [references/test-flow.md](references/test-flow.md)
- Assertion design patterns: [references/assertion-patterns.md](references/assertion-patterns.md)
- Failure triage rules: [references/test-failure-triage.md](references/test-failure-triage.md)
- Detailed test design and coverage guidance: [references/test-design-methodology.md](references/test-design-methodology.md)
- Coverage matrix and quality gates: [references/test-coverage-matrix.md](references/test-coverage-matrix.md)
- Real hardware verification: [../agent-workbench-toolbox/references/hardware-verification.md](../agent-workbench-toolbox/references/hardware-verification.md)
- Test and verification report template: [references/test-report-template.md](references/test-report-template.md)
- Reusable task starters: [assets/task-templates](assets/task-templates)

## Rules

- Change the task yaml before blaming source when acceptance is unclear.
- Regenerate assets after task yaml changes.
- Keep assertions short, deterministic, and machine-readable.
- Use `verify current` when build-only or unit-only evidence is not enough.
- Derive file paths, commands, monitor items, and stable strings from the current repository instead of copying sample template values.
- Use the test report template when summarizing generated cases, coverage, and real-board verification.
