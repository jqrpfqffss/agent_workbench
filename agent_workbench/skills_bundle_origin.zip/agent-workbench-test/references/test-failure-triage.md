# Test Failure Triage

Use this order when a test or verification run fails.

## Layer 1: Task Definition Problem

Choose this when:

- the goal is unclear
- scope is too broad
- acceptance criteria do not match the requested behavior

Action:

- fix the task yaml first
- regenerate assets

## Layer 2: Generated Asset Problem

Choose this when:

- the task is correct but generated assertions or plans are too weak
- the generated files do not cover the intended behavior well

Action:

- refine the task yaml or generated test assets
- rerun `test generate`

## Layer 3: Source Behavior Problem

Choose this when:

- the task and generated assets are sound
- build passes
- evidence shows the firmware behavior violates acceptance

Action:

- coordinate with the feature workflow and keep the fix minimal

## Layer 4: Environment Or Hardware Problem

Choose this when:

- `doctor` fails
- flash fails
- UART path is blocked
- verify reports `blocked`

Action:

- report the blocking layer instead of claiming a source bug
