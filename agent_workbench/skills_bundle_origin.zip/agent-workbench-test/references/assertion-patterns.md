# Assertion Patterns

Use these patterns when writing or refining task-driven acceptance.

## Preferred CLI Assertions

- `cli_contains`
- `cli_not_contains`
- `cli_ready`
- `cli_prompt_seen`
- `cli_no_timeout`

Use short strings sourced from the current project or the task contract, such as:

- `<stable_ack_string_from_new_or_existing_command>`
- `<status_label_from_current_cli_output>`
- `<configured_ready_or_prompt_marker_when_testing_handshake>`

## Preferred Monitor Assertions

Use monitor assertions when runtime state matters:

- `monitor_last_between`

Choose ranges when exact values may vary slightly.

## Preferred File Assertions

Use `file_exists` for generated or evidence artifacts that must exist.

## CLI Diagnostic Assertions

Use `cli_diag_field_between` when the diagnostic JSON exposes numeric fields that should stay in range.

Good uses:

- command count
- timeout count
- receive byte count
- parser error count

Avoid using it when the field is not produced by the current project.

## Stable String Guidance

Preserve these unless the task explicitly changes them:

- ready banner
- prompt
- command table headings
- status labels
- short ack strings

Source these strings from the current repository:

- config and doctor output for ready and prompt
- current CLI surface and transcript evidence for help and status strings
- the task contract for newly introduced strings

## Bad Patterns

- long prose output as an assertion target
- unstable timestamps in asserted strings
- ambiguous success text that changes often

## Assertion Review Checklist

Before accepting generated assertions:

- every assertion maps to one behavior or one evidence requirement
- every string comes from config, current CLI output, or the task contract
- at least one assertion checks the task's new behavior
- regression tasks keep at least one existing command or stable marker
- hardware-dependent tasks include either CLI, diag, or monitor evidence from real-board execution
