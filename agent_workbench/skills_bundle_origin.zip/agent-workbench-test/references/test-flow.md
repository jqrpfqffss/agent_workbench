# Test Flow

## Core Path

1. Resolve or create `task.yaml`
2. `test generate --task <task.yaml>`
3. Read:
   - `blackbox_assertions.yaml`
   - `unit_test_plan.md`
   - `implementation_brief.md`
   - `task_snapshot.json`
4. `test run`
5. If end-to-end confirmation matters, `verify current --task <task.yaml>`
6. `report --latest`

Build the task yaml from current-project discovery:

- use `scan-project` to identify actual source files and existing commands
- use `doctor` to identify the configured ready banner, prompt, and enabled backends
- reuse an existing task if it already captures most of the behavior

## When To Use `verify current`

Use it when:

- the task depends on CLI output
- the task depends on hardware-visible behavior
- unit output alone is not enough to prove acceptance

## What To Read First On Failure

- `unit.log` for unit or host-test failures
- `assertions.jsonl` for black-box failures
- `session_verdict.json` for end-to-end verdict

## When To Stop

Stop and report when:

- the environment is blocked
- flash or UART validation cannot proceed
- the task definition is too ambiguous to generate a trustworthy contract
