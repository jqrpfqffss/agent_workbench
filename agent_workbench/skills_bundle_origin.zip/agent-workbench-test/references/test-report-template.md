# Test And Verification Report Template

Use this template after test generation, test execution, or real-board validation.

## Required Report Shape

```markdown
**Test Result**
<pass | fail | blocked | partial> - <one sentence>

**Task Contract**
- task: `<task path>`
- goal: <task goal>
- scope: <files/modules>

**Generated Assets**
- assertions: <blackbox_assertions.yaml path>
- unit plan: <unit_test_plan.md path>
- implementation brief: <implementation_brief.md path>
- snapshot: <task_snapshot.json path>

**Coverage Summary**
- smoke: <covered/missing/not applicable>
- functional: <covered/missing/not applicable>
- state transition: <covered/missing/not applicable>
- boundary: <covered/missing/not applicable>
- negative/fault: <covered/missing/not applicable>
- regression: <covered/missing/not applicable>
- observability: <covered/missing/not applicable>

**Execution Evidence**
- test run: <pass/fail/skipped> - <unit.log or command JSON>
- verify current: <pass/fail/blocked/skipped> - <summary artifact>
- hardware: <pass/fail/pending/skipped> - <UART/diag/monitor artifact>

**Failures**
- <failing assertion or test>
- layer: <task contract | generated asset | source behavior | environment/hardware>
- evidence: <artifact path>

**Quality Assessment**
- <strong/adequate/weak> - <why>

**Next Step**
<single concrete action if not fully pass>
```

## Rules

- Say when coverage is missing.
- Do not hide weak generated assets behind a passing build.
- For hardware-dependent behavior, explicitly state whether real-board evidence was collected.
- If a test failed because the task contract is wrong, report that instead of blaming firmware.
